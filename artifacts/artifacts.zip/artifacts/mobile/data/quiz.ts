export type Season = "spring" | "summer" | "autumn" | "winter";

export interface QuizOption {
  swatch: string;
  value: string;
  labelKey: string;
  sublabelKey: string;
}

export interface QuizQuestion {
  id: string;
  number: string;
  textKey: string;
  hintKey: string;
  options: QuizOption[];
}

export const questions: QuizQuestion[] = [
  {
    id: "skin_undertone",
    number: "01",
    textKey: "q_skin_undertone_text",
    hintKey: "q_skin_undertone_hint",
    options: [
      { swatch: "#6B8EC4", value: "cool", labelKey: "q_skin_undertone_cool_label", sublabelKey: "q_skin_undertone_cool_sub" },
      { swatch: "#7BA87B", value: "warm", labelKey: "q_skin_undertone_warm_label", sublabelKey: "q_skin_undertone_warm_sub" },
      { swatch: "#8BA89E", value: "neutral", labelKey: "q_skin_undertone_neutral_label", sublabelKey: "q_skin_undertone_neutral_sub" },
      { swatch: "#5FA8A8", value: "neutral_cool", labelKey: "q_skin_undertone_neutral_cool_label", sublabelKey: "q_skin_undertone_neutral_cool_sub" },
    ],
  },
  {
    id: "skin_depth",
    number: "02",
    textKey: "q_skin_depth_text",
    hintKey: "q_skin_depth_hint",
    options: [
      { swatch: "#F5E6D8", value: "fair", labelKey: "q_skin_depth_fair_label", sublabelKey: "q_skin_depth_fair_sub" },
      { swatch: "#E8CBB0", value: "light", labelKey: "q_skin_depth_light_label", sublabelKey: "q_skin_depth_light_sub" },
      { swatch: "#C9956A", value: "medium", labelKey: "q_skin_depth_medium_label", sublabelKey: "q_skin_depth_medium_sub" },
      { swatch: "#A0714A", value: "olive", labelKey: "q_skin_depth_olive_label", sublabelKey: "q_skin_depth_olive_sub" },
      { swatch: "#6B3E26", value: "dark", labelKey: "q_skin_depth_dark_label", sublabelKey: "q_skin_depth_dark_sub" },
      { swatch: "#3B1F0E", value: "deep", labelKey: "q_skin_depth_deep_label", sublabelKey: "q_skin_depth_deep_sub" },
    ],
  },
  {
    id: "skin_surface",
    number: "03",
    textKey: "q_skin_surface_text",
    hintKey: "q_skin_surface_hint",
    options: [
      { swatch: "#F0E8DC", value: "luminous", labelKey: "q_skin_surface_luminous_label", sublabelKey: "q_skin_surface_luminous_sub" },
      { swatch: "#E8C87A", value: "golden", labelKey: "q_skin_surface_golden_label", sublabelKey: "q_skin_surface_golden_sub" },
      { swatch: "#C4A882", value: "matte", labelKey: "q_skin_surface_matte_label", sublabelKey: "q_skin_surface_matte_sub" },
      { swatch: "#E8A898", value: "rosy", labelKey: "q_skin_surface_rosy_label", sublabelKey: "q_skin_surface_rosy_sub" },
    ],
  },
  {
    id: "eye_color",
    number: "04",
    textKey: "q_eye_color_text",
    hintKey: "q_eye_color_hint",
    options: [
      { swatch: "#1A0A00", value: "dark", labelKey: "q_eye_color_dark_label", sublabelKey: "q_eye_color_dark_sub" },
      { swatch: "#8B5E3C", value: "warm_brown", labelKey: "q_eye_color_warm_brown_label", sublabelKey: "q_eye_color_warm_brown_sub" },
      { swatch: "#5C4033", value: "cool_brown", labelKey: "q_eye_color_cool_brown_label", sublabelKey: "q_eye_color_cool_brown_sub" },
      { swatch: "#8B7040", value: "hazel", labelKey: "q_eye_color_hazel_label", sublabelKey: "q_eye_color_hazel_sub" },
      { swatch: "#C8861A", value: "amber", labelKey: "q_eye_color_amber_label", sublabelKey: "q_eye_color_amber_sub" },
      { swatch: "#5E8A5E", value: "green", labelKey: "q_eye_color_green_label", sublabelKey: "q_eye_color_green_sub" },
      { swatch: "#5580A8", value: "blue", labelKey: "q_eye_color_blue_label", sublabelKey: "q_eye_color_blue_sub" },
      { swatch: "#7090A8", value: "blue_grey", labelKey: "q_eye_color_blue_grey_label", sublabelKey: "q_eye_color_blue_grey_sub" },
      { swatch: "#8899AA", value: "grey", labelKey: "q_eye_color_grey_label", sublabelKey: "q_eye_color_grey_sub" },
    ],
  },
  {
    id: "hair_color",
    number: "05",
    textKey: "q_hair_color_text",
    hintKey: "q_hair_color_hint",
    options: [
      { swatch: "#F0E8D0", value: "platinum", labelKey: "q_hair_color_platinum_label", sublabelKey: "q_hair_color_platinum_sub" },
      { swatch: "#D4A84B", value: "golden_blonde", labelKey: "q_hair_color_golden_blonde_label", sublabelKey: "q_hair_color_golden_blonde_sub" },
      { swatch: "#C8BEA0", value: "ash_blonde", labelKey: "q_hair_color_ash_blonde_label", sublabelKey: "q_hair_color_ash_blonde_sub" },
      { swatch: "#A0784A", value: "light_brown", labelKey: "q_hair_color_light_brown_label", sublabelKey: "q_hair_color_light_brown_sub" },
      { swatch: "#5C3820", value: "brown", labelKey: "q_hair_color_brown_label", sublabelKey: "q_hair_color_brown_sub" },
      { swatch: "#1E0E05", value: "dark_brown", labelKey: "q_hair_color_dark_brown_label", sublabelKey: "q_hair_color_dark_brown_sub" },
      { swatch: "#8B2500", value: "red", labelKey: "q_hair_color_red_label", sublabelKey: "q_hair_color_red_sub" },
    ],
  },
  {
    id: "sun_reaction",
    number: "06",
    textKey: "q_sun_reaction_text",
    hintKey: "q_sun_reaction_hint",
    options: [
      { swatch: "#FFB3A0", value: "burns_never", labelKey: "q_sun_reaction_burns_never_label", sublabelKey: "q_sun_reaction_burns_never_sub" },
      { swatch: "#F0C8A0", value: "burns_tans", labelKey: "q_sun_reaction_burns_tans_label", sublabelKey: "q_sun_reaction_burns_tans_sub" },
      { swatch: "#D4A070", value: "tans_well", labelKey: "q_sun_reaction_tans_well_label", sublabelKey: "q_sun_reaction_tans_well_sub" },
      { swatch: "#8B5A38", value: "rarely_burns", labelKey: "q_sun_reaction_rarely_burns_label", sublabelKey: "q_sun_reaction_rarely_burns_sub" },
    ],
  },
  {
    id: "jewelry",
    number: "07",
    textKey: "q_jewelry_text",
    hintKey: "q_jewelry_hint",
    options: [
      { swatch: "#D4A44C", value: "gold", labelKey: "q_jewelry_gold_label", sublabelKey: "q_jewelry_gold_sub" },
      { swatch: "#C0C8D0", value: "silver", labelKey: "q_jewelry_silver_label", sublabelKey: "q_jewelry_silver_sub" },
      { swatch: "#C8B890", value: "both", labelKey: "q_jewelry_both_label", sublabelKey: "q_jewelry_both_sub" },
    ],
  },
  {
    id: "contrast",
    number: "08",
    textKey: "q_contrast_text",
    hintKey: "q_contrast_hint",
    options: [
      { swatch: "#1A1A1A", value: "high", labelKey: "q_contrast_high_label", sublabelKey: "q_contrast_high_sub" },
      { swatch: "#888888", value: "medium", labelKey: "q_contrast_medium_label", sublabelKey: "q_contrast_medium_sub" },
      { swatch: "#CCCCCC", value: "low", labelKey: "q_contrast_low_label", sublabelKey: "q_contrast_low_sub" },
    ],
  },
  {
    id: "warm_cool",
    number: "09",
    textKey: "q_warm_cool_text",
    hintKey: "q_warm_cool_hint",
    options: [
      { swatch: "#D4784C", value: "warm", labelKey: "q_warm_cool_warm_label", sublabelKey: "q_warm_cool_warm_sub" },
      { swatch: "#6878C8", value: "cool", labelKey: "q_warm_cool_cool_label", sublabelKey: "q_warm_cool_cool_sub" },
      { swatch: "#C4B4C0", value: "neutral", labelKey: "q_warm_cool_neutral_label", sublabelKey: "q_warm_cool_neutral_sub" },
      { swatch: "#482848", value: "deep", labelKey: "q_warm_cool_deep_label", sublabelKey: "q_warm_cool_deep_sub" },
    ],
  },
  {
    id: "makeup_feel",
    number: "10",
    textKey: "q_makeup_feel_text",
    hintKey: "q_makeup_feel_hint",
    options: [
      { swatch: "#F0C8A0", value: "natural", labelKey: "q_makeup_feel_natural_label", sublabelKey: "q_makeup_feel_natural_sub" },
      { swatch: "#E04878", value: "bold", labelKey: "q_makeup_feel_bold_label", sublabelKey: "q_makeup_feel_bold_sub" },
      { swatch: "#483848", value: "smoky", labelKey: "q_makeup_feel_smoky_label", sublabelKey: "q_makeup_feel_smoky_sub" },
      { swatch: "#C86860", value: "classic", labelKey: "q_makeup_feel_classic_label", sublabelKey: "q_makeup_feel_classic_sub" },
    ],
  },
];

export function computeSeason(answers: Record<string, string>): Season {
  const score = { warm: 0, cool: 0, light: 0, dark: 0, clear: 0, muted: 0 };

  if (answers["skin_undertone"] === "warm") score.warm += 3;
  if (answers["skin_undertone"] === "cool") score.cool += 3;
  if (["neutral", "neutral_cool"].includes(answers["skin_undertone"] ?? "")) { score.warm += 1; score.cool += 1; }

  if (["fair", "light"].includes(answers["skin_depth"] ?? "")) score.light += 2;
  if (["dark", "deep"].includes(answers["skin_depth"] ?? "")) score.dark += 2;
  if (answers["skin_depth"] === "olive") score.warm += 2;

  if (answers["skin_surface"] === "golden") score.warm += 2;
  if (answers["skin_surface"] === "rosy") score.cool += 2;
  if (answers["skin_surface"] === "luminous") score.clear += 1;

  if (["dark", "warm_brown", "amber", "hazel"].includes(answers["eye_color"] ?? "")) score.warm += 1;
  if (["blue", "grey", "blue_grey"].includes(answers["eye_color"] ?? "")) score.cool += 2;
  if (answers["eye_color"] === "cool_brown") score.cool += 1;
  if (["green", "hazel"].includes(answers["eye_color"] ?? "")) { score.warm += 1; score.muted += 1; }

  if (["golden_blonde", "light_brown", "red"].includes(answers["hair_color"] ?? "")) score.warm += 2;
  if (["platinum", "ash_blonde"].includes(answers["hair_color"] ?? "")) score.cool += 2;
  if (["brown", "dark_brown"].includes(answers["hair_color"] ?? "")) score.dark += 1;

  if (["burns_never", "burns_tans"].includes(answers["sun_reaction"] ?? "")) score.light += 1;
  if (["tans_well", "rarely_burns"].includes(answers["sun_reaction"] ?? "")) { score.warm += 1; score.dark += 1; }

  if (answers["jewelry"] === "gold") score.warm += 2;
  if (answers["jewelry"] === "silver") score.cool += 2;

  if (answers["contrast"] === "high") score.clear += 2;
  if (answers["contrast"] === "low") score.muted += 2;

  if (answers["warm_cool"] === "warm") score.warm += 2;
  if (answers["warm_cool"] === "cool") score.cool += 2;
  if (answers["warm_cool"] === "deep") score.dark += 2;
  if (answers["warm_cool"] === "neutral") score.muted += 1;

  const isWarm = score.warm > score.cool;
  const isLight = score.light > score.dark;

  if (isWarm && isLight) return "spring";
  if (!isWarm && isLight) return "summer";
  if (isWarm && !isLight) return "autumn";
  return "winter";
}

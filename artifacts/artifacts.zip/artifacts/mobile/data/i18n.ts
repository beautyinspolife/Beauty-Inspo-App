export type Language = "en" | "fr" | "it" | "es" | "pt" | "de";

export const LANGUAGES: { code: Language; label: string; flag: string }[] = [
  { code: "en", label: "English", flag: "🇬🇧" },
  { code: "fr", label: "Français", flag: "🇫🇷" },
  { code: "it", label: "Italiano", flag: "🇮🇹" },
  { code: "es", label: "Español", flag: "🇪🇸" },
  { code: "pt", label: "Português", flag: "🇧🇷" },
  { code: "de", label: "Deutsch", flag: "🇩🇪" },
];

type Translations = {
  // App
  app_name: string;
  app_tag: string;
  app_tagline: string;
  hero_line1: string;
  hero_accent: string;
  // Welcome
  start_quiz: string;
  retake_quiz: string;
  view_my_result: string;
  your_season_label: string;
  steps_skin: string;
  steps_colors: string;
  steps_result: string;
  // Quiz
  question_of: string;
  next: string;
  back: string;
  reveal_colors: string;
  // Result
  your_season_title: string;
  palette_title: string;
  palette_subtitle: string;
  avoid_title: string;
  avoid_subtitle: string;
  style_section: string;
  style_subtitle: string;
  hair_title: string;
  hair_subtitle: string;
  jewelry_title: string;
  jewelry_subtitle: string;
  wardrobe_title: string;
  wardrobe_essentials: string;
  wardrobe_accents: string;
  wardrobe_neutrals: string;
  wardrobe_avoid: string;
  makeup_section: string;
  makeup_subtitle: string;
  makeup_foundation: string;
  makeup_corrector: string;
  makeup_concealer: string;
  makeup_blush: string;
  makeup_bronzer: string;
  makeup_highlighter: string;
  makeup_eye_pencil: string;
  makeup_brow_pencil: string;
  makeup_mascara: string;
  makeup_lip_liner: string;
  makeup_gloss: string;
  makeup_lipstick: string;
  shop_makeup: string;
  restart_quiz: string;
  // Paywall
  get_premium: string;
  get_premium_subtitle: string;
  unlock_to_see: string;
  // Subscribe
  subscribe_title: string;
  subscribe_subtitle: string;
  most_popular: string;
  per_day: string;
  per_week_min: string;
  week_commitment: string;
  subscribe_btn: string;
  restore: string;
  plan1_name: string;
  plan1_feature1: string;
  plan1_feature2: string;
  plan2_name: string;
  plan2_feature1: string;
  plan2_feature2: string;
  plan2_feature3: string;
  plan2_feature4: string;
  plan3_name: string;
  plan3_feature1: string;
  plan3_feature2: string;
  plan3_feature3: string;
  // Auth
  auth_title_login: string;
  auth_title_register: string;
  auth_email: string;
  auth_password: string;
  auth_signin: string;
  auth_register: string;
  auth_switch_to_login: string;
  auth_switch_to_register: string;
  auth_guest: string;
  auth_email_taken: string;
  auth_invalid: string;
  // Questions
  q_skin_undertone_text: string;
  q_skin_undertone_hint: string;
  q_skin_undertone_cool_label: string;
  q_skin_undertone_cool_sub: string;
  q_skin_undertone_warm_label: string;
  q_skin_undertone_warm_sub: string;
  q_skin_undertone_neutral_label: string;
  q_skin_undertone_neutral_sub: string;
  q_skin_undertone_neutral_cool_label: string;
  q_skin_undertone_neutral_cool_sub: string;
  q_skin_depth_text: string;
  q_skin_depth_hint: string;
  q_skin_depth_fair_label: string;
  q_skin_depth_fair_sub: string;
  q_skin_depth_light_label: string;
  q_skin_depth_light_sub: string;
  q_skin_depth_medium_label: string;
  q_skin_depth_medium_sub: string;
  q_skin_depth_olive_label: string;
  q_skin_depth_olive_sub: string;
  q_skin_depth_dark_label: string;
  q_skin_depth_dark_sub: string;
  q_skin_depth_deep_label: string;
  q_skin_depth_deep_sub: string;
  q_skin_surface_text: string;
  q_skin_surface_hint: string;
  q_skin_surface_luminous_label: string;
  q_skin_surface_luminous_sub: string;
  q_skin_surface_golden_label: string;
  q_skin_surface_golden_sub: string;
  q_skin_surface_matte_label: string;
  q_skin_surface_matte_sub: string;
  q_skin_surface_rosy_label: string;
  q_skin_surface_rosy_sub: string;
  q_eye_color_text: string;
  q_eye_color_hint: string;
  q_eye_color_dark_label: string;
  q_eye_color_dark_sub: string;
  q_eye_color_warm_brown_label: string;
  q_eye_color_warm_brown_sub: string;
  q_eye_color_cool_brown_label: string;
  q_eye_color_cool_brown_sub: string;
  q_eye_color_hazel_label: string;
  q_eye_color_hazel_sub: string;
  q_eye_color_amber_label: string;
  q_eye_color_amber_sub: string;
  q_eye_color_green_label: string;
  q_eye_color_green_sub: string;
  q_eye_color_blue_label: string;
  q_eye_color_blue_sub: string;
  q_eye_color_blue_grey_label: string;
  q_eye_color_blue_grey_sub: string;
  q_eye_color_grey_label: string;
  q_eye_color_grey_sub: string;
  q_hair_color_text: string;
  q_hair_color_hint: string;
  q_hair_color_platinum_label: string;
  q_hair_color_platinum_sub: string;
  q_hair_color_golden_blonde_label: string;
  q_hair_color_golden_blonde_sub: string;
  q_hair_color_ash_blonde_label: string;
  q_hair_color_ash_blonde_sub: string;
  q_hair_color_light_brown_label: string;
  q_hair_color_light_brown_sub: string;
  q_hair_color_brown_label: string;
  q_hair_color_brown_sub: string;
  q_hair_color_dark_brown_label: string;
  q_hair_color_dark_brown_sub: string;
  q_hair_color_red_label: string;
  q_hair_color_red_sub: string;
  q_sun_reaction_text: string;
  q_sun_reaction_hint: string;
  q_sun_reaction_burns_never_label: string;
  q_sun_reaction_burns_never_sub: string;
  q_sun_reaction_burns_tans_label: string;
  q_sun_reaction_burns_tans_sub: string;
  q_sun_reaction_tans_well_label: string;
  q_sun_reaction_tans_well_sub: string;
  q_sun_reaction_rarely_burns_label: string;
  q_sun_reaction_rarely_burns_sub: string;
  q_jewelry_text: string;
  q_jewelry_hint: string;
  q_jewelry_gold_label: string;
  q_jewelry_gold_sub: string;
  q_jewelry_silver_label: string;
  q_jewelry_silver_sub: string;
  q_jewelry_both_label: string;
  q_jewelry_both_sub: string;
  q_contrast_text: string;
  q_contrast_hint: string;
  q_contrast_high_label: string;
  q_contrast_high_sub: string;
  q_contrast_medium_label: string;
  q_contrast_medium_sub: string;
  q_contrast_low_label: string;
  q_contrast_low_sub: string;
  q_warm_cool_text: string;
  q_warm_cool_hint: string;
  q_warm_cool_warm_label: string;
  q_warm_cool_warm_sub: string;
  q_warm_cool_cool_label: string;
  q_warm_cool_cool_sub: string;
  q_warm_cool_neutral_label: string;
  q_warm_cool_neutral_sub: string;
  q_warm_cool_deep_label: string;
  q_warm_cool_deep_sub: string;
  q_makeup_feel_text: string;
  q_makeup_feel_hint: string;
  q_makeup_feel_natural_label: string;
  q_makeup_feel_natural_sub: string;
  q_makeup_feel_bold_label: string;
  q_makeup_feel_bold_sub: string;
  q_makeup_feel_smoky_label: string;
  q_makeup_feel_smoky_sub: string;
  q_makeup_feel_classic_label: string;
  q_makeup_feel_classic_sub: string;
  // Season names
  season_spring: string;
  season_summer: string;
  season_autumn: string;
  season_winter: string;
  season_spring_sub: string;
  season_summer_sub: string;
  season_autumn_sub: string;
  season_winter_sub: string;
  season_spring_desc: string;
  season_summer_desc: string;
  season_autumn_desc: string;
  season_winter_desc: string;
  you_are_a: string;
};

const en: Translations = {
  app_name: "Palette & Teintes",
  app_tag: "PERSONAL COLOR ANALYSIS",
  app_tagline: "10 questions to reveal your chromatic season, makeup colors and wardrobe palette.",
  hero_line1: "Discover your",
  hero_accent: "perfect palette",
  start_quiz: "Start the quiz",
  retake_quiz: "Retake the quiz",
  view_my_result: "View my result",
  your_season_label: "Your season",
  steps_skin: "Skin",
  steps_colors: "Colors",
  steps_result: "Result",
  question_of: "of",
  next: "Continue",
  back: "Back",
  reveal_colors: "Reveal my colors",
  your_season_title: "Your Analysis",
  palette_title: "Your Color Palette",
  palette_subtitle: "These shades naturally harmonize with your coloring.",
  avoid_title: "Colors to Avoid",
  avoid_subtitle: "These tones can dull your natural radiance.",
  style_section: "Your Style Colors",
  style_subtitle: "Hair, jewelry & wardrobe colors tailored to you.",
  hair_title: "Recommended Hair Colors",
  hair_subtitle: "Shades that illuminate your complexion.",
  jewelry_title: "Your Jewelry Palette",
  jewelry_subtitle: "Metals and gems that enhance your features.",
  wardrobe_title: "Your Wardrobe Palette",
  wardrobe_essentials: "Essentials",
  wardrobe_accents: "Accent Colors",
  wardrobe_neutrals: "Neutrals",
  wardrobe_avoid: "Avoid",
  makeup_section: "Your Makeup Palette",
  makeup_subtitle: "Every product, every shade — matched to your complexion.",
  makeup_foundation: "Foundation",
  makeup_corrector: "Color Corrector",
  makeup_concealer: "Concealer",
  makeup_blush: "Blush",
  makeup_bronzer: "Bronzer & Contour",
  makeup_highlighter: "Highlighter",
  makeup_eye_pencil: "Eye Pencil",
  makeup_brow_pencil: "Brow Pencil",
  makeup_mascara: "Mascara",
  makeup_lip_liner: "Lip Liner",
  makeup_gloss: "Gloss",
  makeup_lipstick: "Lipstick",
  shop_makeup: "Shop the Makeup",
  restart_quiz: "Retake the quiz",
  get_premium: "Unlock Full Analysis",
  get_premium_subtitle: "Discover your complete color profile",
  unlock_to_see: "Unlock to reveal",
  subscribe_title: "Choose Your Plan",
  subscribe_subtitle: "Unlock your full color profile. Minimum 1 week commitment.",
  most_popular: "Most Popular",
  per_day: "/day",
  per_week_min: "min. 1 week",
  week_commitment: "Minimum 1 week",
  subscribe_btn: "Get Access",
  restore: "Restore purchases",
  plan1_name: "Essentials",
  plan1_feature1: "Your chromatic season",
  plan1_feature2: "General color palette (10 shades)",
  plan2_name: "Style",
  plan2_feature1: "Everything in Essentials",
  plan2_feature2: "Recommended hair colors",
  plan2_feature3: "Jewelry guide",
  plan2_feature4: "Wardrobe palette by category",
  plan3_name: "Full Glam",
  plan3_feature1: "Everything in Style",
  plan3_feature2: "Complete makeup palette",
  plan3_feature3: "All product shades matched to your skin",
  auth_title_login: "Sign In",
  auth_title_register: "Create Account",
  auth_email: "Email address",
  auth_password: "Password",
  auth_signin: "Sign In",
  auth_register: "Create Account",
  auth_switch_to_login: "Already have an account? Sign in",
  auth_switch_to_register: "No account? Create one",
  auth_guest: "Continue without account",
  auth_email_taken: "This email is already registered.",
  auth_invalid: "Incorrect email or password.",
  q_skin_undertone_text: "What color do your wrist veins appear?",
  q_skin_undertone_hint: "Look in natural light with a white or grey background behind your arm.",
  q_skin_undertone_cool_label: "Blue or purple",
  q_skin_undertone_cool_sub: "Clearly blue, sometimes violet",
  q_skin_undertone_warm_label: "Green or olive",
  q_skin_undertone_warm_sub: "Leaning toward yellow-green",
  q_skin_undertone_neutral_label: "Mix of both",
  q_skin_undertone_neutral_sub: "Hard to distinguish",
  q_skin_undertone_neutral_cool_label: "Blue-green",
  q_skin_undertone_neutral_cool_sub: "Turquoise, neither warm nor cool",
  q_skin_depth_text: "What is your natural skin depth?",
  q_skin_depth_hint: "Without makeup, in natural light.",
  q_skin_depth_fair_label: "Very fair / Porcelain",
  q_skin_depth_fair_sub: "Burns easily in the sun",
  q_skin_depth_light_label: "Light / Ivory",
  q_skin_depth_light_sub: "Tans slightly or burns quickly",
  q_skin_depth_medium_label: "Medium / Golden beige",
  q_skin_depth_medium_sub: "Tans well, keeps a tan",
  q_skin_depth_olive_label: "Olive / Amber",
  q_skin_depth_olive_sub: "Naturally golden or olive tone",
  q_skin_depth_dark_label: "Dark / Brown",
  q_skin_depth_dark_sub: "Rich, deep complexion",
  q_skin_depth_deep_label: "Very dark / Ebony",
  q_skin_depth_deep_sub: "Very deep skin tone",
  q_skin_surface_text: "What is your skin's natural texture?",
  q_skin_surface_hint: "Observe your natural radiance.",
  q_skin_surface_luminous_label: "Luminous / Pearlescent",
  q_skin_surface_luminous_sub: "A visible pearly glow",
  q_skin_surface_golden_label: "Golden / Sun-kissed",
  q_skin_surface_golden_sub: "A warm, sunny radiance",
  q_skin_surface_matte_label: "Matte / Satin",
  q_skin_surface_matte_sub: "Little natural shine",
  q_skin_surface_rosy_label: "Rosy / Peachy",
  q_skin_surface_rosy_sub: "Visible pink or peach tones",
  q_eye_color_text: "What is your eye color?",
  q_eye_color_hint: "Observe the main iris, ignoring light reflections.",
  q_eye_color_dark_label: "Black / Very dark",
  q_eye_color_dark_sub: "So dark brown it appears black",
  q_eye_color_warm_brown_label: "Warm brown",
  q_eye_color_warm_brown_sub: "Honey, hazelnut, caramel",
  q_eye_color_cool_brown_label: "Cool brown",
  q_eye_color_cool_brown_sub: "Dark brown with grey reflections",
  q_eye_color_hazel_label: "Hazel",
  q_eye_color_hazel_sub: "Green-brown mix, changes with light",
  q_eye_color_amber_label: "Amber / Golden",
  q_eye_color_amber_sub: "Warm golden-brown, almost orange",
  q_eye_color_green_label: "Green",
  q_eye_color_green_sub: "Green, khaki, green-hazel",
  q_eye_color_blue_label: "Blue",
  q_eye_color_blue_sub: "Light blue, grey-blue, steel blue",
  q_eye_color_blue_grey_label: "Blue-grey",
  q_eye_color_blue_grey_sub: "A cool, silvery blue",
  q_eye_color_grey_label: "Grey",
  q_eye_color_grey_sub: "Light grey or steel grey",
  q_hair_color_text: "What is your natural or current hair color?",
  q_hair_color_hint: "The shade you have most often.",
  q_hair_color_platinum_label: "Platinum / White blonde",
  q_hair_color_platinum_sub: "Very light, almost white",
  q_hair_color_golden_blonde_label: "Golden / Honey blonde",
  q_hair_color_golden_blonde_sub: "Warm, luminous highlights",
  q_hair_color_ash_blonde_label: "Ash / Cool blonde",
  q_hair_color_ash_blonde_sub: "No warm tones, beige-grey",
  q_hair_color_light_brown_label: "Light brown",
  q_hair_color_light_brown_sub: "Luminous brown with highlights",
  q_hair_color_brown_label: "Medium / Dark brown",
  q_hair_color_brown_sub: "Deep brown, warm or neutral",
  q_hair_color_dark_brown_label: "Very dark brown / Black",
  q_hair_color_dark_brown_sub: "Very dark, few highlights",
  q_hair_color_red_label: "Red / Auburn",
  q_hair_color_red_sub: "Red or orange tints",
  q_sun_reaction_text: "How does your skin react to sun?",
  q_sun_reaction_hint: "Without sun protection, after moderate exposure.",
  q_sun_reaction_burns_never_label: "Burns, never tans",
  q_sun_reaction_burns_never_sub: "Phototype I",
  q_sun_reaction_burns_tans_label: "Burns first, tans little",
  q_sun_reaction_burns_tans_sub: "Phototype II",
  q_sun_reaction_tans_well_label: "Rarely burns, tans well",
  q_sun_reaction_tans_well_sub: "Phototype III–IV",
  q_sun_reaction_rarely_burns_label: "Almost never burns",
  q_sun_reaction_rarely_burns_sub: "Phototype V–VI",
  q_jewelry_text: "Which metal color enhances your skin most?",
  q_jewelry_hint: "Try both if you can!",
  q_jewelry_gold_label: "Gold — yellow, rose gold",
  q_jewelry_gold_sub: "Warm metals illuminate you",
  q_jewelry_silver_label: "Silver — platinum, white",
  q_jewelry_silver_sub: "Cool metals suit you better",
  q_jewelry_both_label: "Both work for me",
  q_jewelry_both_sub: "Versatile depending on outfits",
  q_contrast_text: "What is the contrast between your skin, eyes and hair?",
  q_contrast_hint: "Imagine a black-and-white photo — the gap between lightest and darkest.",
  q_contrast_high_label: "High contrast",
  q_contrast_high_sub: "E.g. fair skin + very dark eyes/hair",
  q_contrast_medium_label: "Medium contrast",
  q_contrast_medium_sub: "E.g. all brown or all medium tones",
  q_contrast_low_label: "Low contrast",
  q_contrast_low_sub: "E.g. similar lightness in eyes/hair/skin",
  q_warm_cool_text: "Which colors seem to naturally flatter you?",
  q_warm_cool_hint: "Trust your instincts or feedback you've received.",
  q_warm_cool_warm_label: "Warm colors",
  q_warm_cool_warm_sub: "Terracotta, orange, yellow, olive, brown",
  q_warm_cool_cool_label: "Cool colors",
  q_warm_cool_cool_sub: "Navy, mauve, fuchsia pink, grey",
  q_warm_cool_neutral_label: "Neutrals / Soft tones",
  q_warm_cool_neutral_sub: "Beige, powder pink, lavender, taupe",
  q_warm_cool_deep_label: "Deep / Rich colors",
  q_warm_cool_deep_sub: "Burgundy, forest green, navy, plum",
  q_makeup_feel_text: "Which makeup style suits you most?",
  q_makeup_feel_hint: "The style where you feel most like yourself.",
  q_makeup_feel_natural_label: "Natural & Glow",
  q_makeup_feel_natural_sub: "No-makeup makeup, luminous",
  q_makeup_feel_bold_label: "Colorful & Vibrant",
  q_makeup_feel_bold_sub: "Bold colors, statement eyes",
  q_makeup_feel_smoky_label: "Smoky & Intense",
  q_makeup_feel_smoky_sub: "Intense, deep eye looks",
  q_makeup_feel_classic_label: "Classic & Elegant",
  q_makeup_feel_classic_sub: "Nude, lipstick, refined",
  season_spring: "Spring",
  season_summer: "Summer",
  season_autumn: "Autumn",
  season_winter: "Winter",
  season_spring_sub: "Warm Spring",
  season_summer_sub: "Cool Summer",
  season_autumn_sub: "Warm Autumn",
  season_winter_sub: "Cool Winter",
  season_spring_desc: "You radiate warmth and lightness. Your complexion is luminous, golden or peachy, with a natural clarity. The colors that make you shine are warm, luminous and never too saturated.",
  season_summer_desc: "You possess a soft, refined beauty. Your complexion has cool or rosy undertones, and you glow in soft, powdery, delicately cool shades. Anything too saturated or too warm can dull you.",
  season_autumn_desc: "You embody the richness of autumn. Your complexion is deep, golden or olive, with rich reflections. Dark, earthy colors belong to you — they give you a magnetic depth.",
  season_winter_desc: "You are made for strong contrasts and intense colors. Your complexion is either very light or very dark, with cool undertones. You shine in black, pure white and deep saturated colors.",
  you_are_a: "You are a",
};

const fr: Translations = {
  app_name: "Palette & Teintes",
  app_tag: "ANALYSE CHROMATIQUE PERSONNALISÉE",
  app_tagline: "10 questions pour révéler ta saison chromatique, tes couleurs maquillage et ta palette vestimentaire.",
  hero_line1: "Découvre ta",
  hero_accent: "palette idéale",
  start_quiz: "Commencer le quiz",
  retake_quiz: "Refaire le quiz",
  view_my_result: "Voir mon résultat",
  your_season_label: "Ta saison",
  steps_skin: "Teint",
  steps_colors: "Couleurs",
  steps_result: "Résultat",
  question_of: "sur",
  next: "Continuer",
  back: "Retour",
  reveal_colors: "Révéler mes couleurs",
  your_season_title: "Ton Analyse",
  palette_title: "Ta Palette de Couleurs",
  palette_subtitle: "Ces teintes s'harmonisent naturellement avec ta coloration.",
  avoid_title: "Couleurs à Éviter",
  avoid_subtitle: "Ces teintes peuvent ternir ton éclat naturel.",
  style_section: "Tes Couleurs Style",
  style_subtitle: "Couleurs cheveux, bijoux & garde-robe adaptées à toi.",
  hair_title: "Couleurs de Cheveux Recommandées",
  hair_subtitle: "Les teintes qui illuminent ton teint.",
  jewelry_title: "Ta Palette Bijoux",
  jewelry_subtitle: "Les métaux et pierres qui mettent tes traits en valeur.",
  wardrobe_title: "Ta Palette Vestimentaire",
  wardrobe_essentials: "Basiques",
  wardrobe_accents: "Couleurs Accent",
  wardrobe_neutrals: "Neutres",
  wardrobe_avoid: "À Éviter",
  makeup_section: "Ta Palette Maquillage",
  makeup_subtitle: "Chaque produit, chaque nuance — adapté à ton teint.",
  makeup_foundation: "Fond de Teint",
  makeup_corrector: "Correcteur de Teint",
  makeup_concealer: "Anti-cernes",
  makeup_blush: "Blush",
  makeup_bronzer: "Bronzer & Contouring",
  makeup_highlighter: "Highlighter",
  makeup_eye_pencil: "Crayon Yeux",
  makeup_brow_pencil: "Crayon Sourcils",
  makeup_mascara: "Mascara",
  makeup_lip_liner: "Crayon Lèvres",
  makeup_gloss: "Gloss",
  makeup_lipstick: "Rouge à Lèvres",
  shop_makeup: "Shop the Makeup",
  restart_quiz: "Recommencer le quiz",
  get_premium: "Débloquer l'Analyse Complète",
  get_premium_subtitle: "Découvre ton profil colorimétrique complet",
  unlock_to_see: "Débloquer pour voir",
  subscribe_title: "Choisir Ton Offre",
  subscribe_subtitle: "Débloque ton profil complet. Engagement minimum 1 semaine.",
  most_popular: "Plus Populaire",
  per_day: "/jour",
  per_week_min: "min. 1 semaine",
  week_commitment: "Minimum 1 semaine",
  subscribe_btn: "Accéder",
  restore: "Restaurer mes achats",
  plan1_name: "Essentiels",
  plan1_feature1: "Ta saison chromatique",
  plan1_feature2: "Palette générale (10 couleurs)",
  plan2_name: "Style",
  plan2_feature1: "Tout ce qui est dans Essentiels",
  plan2_feature2: "Couleurs de cheveux recommandées",
  plan2_feature3: "Guide bijoux",
  plan2_feature4: "Palette vestimentaire par catégorie",
  plan3_name: "Full Glam",
  plan3_feature1: "Tout ce qui est dans Style",
  plan3_feature2: "Palette maquillage complète",
  plan3_feature3: "Toutes les nuances de produits selon ton teint",
  auth_title_login: "Connexion",
  auth_title_register: "Créer un Compte",
  auth_email: "Adresse email",
  auth_password: "Mot de passe",
  auth_signin: "Se connecter",
  auth_register: "Créer un compte",
  auth_switch_to_login: "Déjà un compte ? Se connecter",
  auth_switch_to_register: "Pas de compte ? En créer un",
  auth_guest: "Continuer sans compte",
  auth_email_taken: "Cet email est déjà enregistré.",
  auth_invalid: "Email ou mot de passe incorrect.",
  q_skin_undertone_text: "Quelle couleur prennent tes veines au poignet ?",
  q_skin_undertone_hint: "Regarde à la lumière naturelle, avec un fond blanc ou gris derrière ton bras.",
  q_skin_undertone_cool_label: "Bleues ou violettes",
  q_skin_undertone_cool_sub: "Nettement bleues, parfois violacées",
  q_skin_undertone_warm_label: "Vertes ou olive",
  q_skin_undertone_warm_sub: "Tirant vers le vert-jaune",
  q_skin_undertone_neutral_label: "Mélange des deux",
  q_skin_undertone_neutral_sub: "Difficile à distinguer",
  q_skin_undertone_neutral_cool_label: "Bleu-vert",
  q_skin_undertone_neutral_cool_sub: "Turquoise, ni chaud ni froid",
  q_skin_depth_text: "Quelle est la profondeur de ton teint naturel ?",
  q_skin_depth_hint: "Sans maquillage, en lumière naturelle.",
  q_skin_depth_fair_label: "Très clair / Porcelaine",
  q_skin_depth_fair_sub: "Se brûle facilement au soleil",
  q_skin_depth_light_label: "Clair / Ivoire",
  q_skin_depth_light_sub: "Bronze légèrement ou brûle vite",
  q_skin_depth_medium_label: "Médium / Beige doré",
  q_skin_depth_medium_sub: "Bronze bien, garde le hâle",
  q_skin_depth_olive_label: "Olivâtre / Ambre",
  q_skin_depth_olive_sub: "Teinte naturellement dorée ou olive",
  q_skin_depth_dark_label: "Foncé / Brun",
  q_skin_depth_dark_sub: "Riche, profond",
  q_skin_depth_deep_label: "Très foncé / Ébène",
  q_skin_depth_deep_sub: "Ton de peau très profond",
  q_skin_surface_text: "Quelle est la texture naturelle de ta peau ?",
  q_skin_surface_hint: "Observe ton éclat naturel.",
  q_skin_surface_luminous_label: "Lumineuse / Nacrée",
  q_skin_surface_luminous_sub: "Un éclat nacré visible",
  q_skin_surface_golden_label: "Dorée / Solaire",
  q_skin_surface_golden_sub: "Un éclat chaud, ensoleillé",
  q_skin_surface_matte_label: "Mate / Satinée",
  q_skin_surface_matte_sub: "Peu de brillance naturelle",
  q_skin_surface_rosy_label: "Rosée / Pêche",
  q_skin_surface_rosy_sub: "Des nuances roses ou pêche visibles",
  q_eye_color_text: "Quelle est la couleur de tes yeux ?",
  q_eye_color_hint: "Observe l'iris principal, en ignorant les éclats lumineux.",
  q_eye_color_dark_label: "Noirs / Très foncés",
  q_eye_color_dark_sub: "Brun si foncé qu'il paraît noir",
  q_eye_color_warm_brown_label: "Marrons chauds",
  q_eye_color_warm_brown_sub: "Miel, noisette, caramel",
  q_eye_color_cool_brown_label: "Marrons froids",
  q_eye_color_cool_brown_sub: "Brun foncé avec reflets gris",
  q_eye_color_hazel_label: "Noisette",
  q_eye_color_hazel_sub: "Mélange vert-brun, change selon la lumière",
  q_eye_color_amber_label: "Ambre / Doré",
  q_eye_color_amber_sub: "Brun doré chaud, presque orangé",
  q_eye_color_green_label: "Verts",
  q_eye_color_green_sub: "Verts, kaki, verts-noisette",
  q_eye_color_blue_label: "Bleus",
  q_eye_color_blue_sub: "Bleu clair, gris-bleu, bleu acier",
  q_eye_color_blue_grey_label: "Bleu-gris",
  q_eye_color_blue_grey_sub: "Un bleu froid et argenté",
  q_eye_color_grey_label: "Gris",
  q_eye_color_grey_sub: "Gris clairs ou gris acier",
  q_hair_color_text: "Quelle est ta couleur de cheveux naturelle ou actuelle ?",
  q_hair_color_hint: "La teinte que tu as le plus souvent.",
  q_hair_color_platinum_label: "Blond platine / Blanc",
  q_hair_color_platinum_sub: "Très clair, presque blanc",
  q_hair_color_golden_blonde_label: "Blond doré / Miel",
  q_hair_color_golden_blonde_sub: "Reflets chauds et lumineux",
  q_hair_color_ash_blonde_label: "Blond froid / Cendré",
  q_hair_color_ash_blonde_sub: "Sans reflets chauds, beige-gris",
  q_hair_color_light_brown_label: "Châtain clair",
  q_hair_color_light_brown_sub: "Brun lumineux avec reflets",
  q_hair_color_brown_label: "Châtain foncé / Brun",
  q_hair_color_brown_sub: "Brun profond, chaud ou neutre",
  q_hair_color_dark_brown_label: "Brun foncé / Noir",
  q_hair_color_dark_brown_sub: "Très foncé, peu de reflets",
  q_hair_color_red_label: "Roux / Acajou",
  q_hair_color_red_sub: "Reflets rouges ou orangés",
  q_sun_reaction_text: "Comment ta peau réagit-elle au soleil ?",
  q_sun_reaction_hint: "Sans protection solaire, après une exposition modérée.",
  q_sun_reaction_burns_never_label: "Coup de soleil, jamais bronze",
  q_sun_reaction_burns_never_sub: "Phototype I",
  q_sun_reaction_burns_tans_label: "Coup de soleil, bronze peu",
  q_sun_reaction_burns_tans_sub: "Phototype II",
  q_sun_reaction_tans_well_label: "Rarement brûle, bronze bien",
  q_sun_reaction_tans_well_sub: "Phototype III–IV",
  q_sun_reaction_rarely_burns_label: "Ne brûle presque jamais",
  q_sun_reaction_rarely_burns_sub: "Phototype V–VI",
  q_jewelry_text: "Quelle couleur de métal met le mieux ta peau en valeur ?",
  q_jewelry_hint: "Essaie les deux si tu peux !",
  q_jewelry_gold_label: "Or — doré, rose gold",
  q_jewelry_gold_sub: "Les métaux chauds t'illuminent",
  q_jewelry_silver_label: "Argent — platine, blanc",
  q_jewelry_silver_sub: "Les métaux froids te vont mieux",
  q_jewelry_both_label: "Les deux me vont",
  q_jewelry_both_sub: "Polyvalente selon les tenues",
  q_contrast_text: "Quel est le contraste entre ta peau, tes yeux et tes cheveux ?",
  q_contrast_hint: "Imagine une photo en noir et blanc — l'écart entre le plus clair et le plus foncé.",
  q_contrast_high_label: "Fort contraste",
  q_contrast_high_sub: "Ex. peau claire + yeux/cheveux très foncés",
  q_contrast_medium_label: "Contraste moyen",
  q_contrast_medium_sub: "Ex. tout brun ou tout clair/moyen",
  q_contrast_low_label: "Faible contraste",
  q_contrast_low_sub: "Ex. yeux/cheveux/peau proches en clarté",
  q_warm_cool_text: "Quelles couleurs te semblent te mettre en valeur naturellement ?",
  q_warm_cool_hint: "Fais confiance à tes instincts ou aux retours que tu as reçus.",
  q_warm_cool_warm_label: "Couleurs chaudes",
  q_warm_cool_warm_sub: "Terracotta, orange, jaune, olive, brun",
  q_warm_cool_cool_label: "Couleurs froides",
  q_warm_cool_cool_sub: "Bleu marine, mauve, rose fuchsia, gris",
  q_warm_cool_neutral_label: "Neutres / Douces",
  q_warm_cool_neutral_sub: "Beige, rose poudré, lavande, taupe",
  q_warm_cool_deep_label: "Couleurs profondes",
  q_warm_cool_deep_sub: "Bordeaux, forêt, marine, prune",
  q_makeup_feel_text: "Quel maquillage te correspond le plus ?",
  q_makeup_feel_hint: "Le style dans lequel tu te sens le plus toi-même.",
  q_makeup_feel_natural_label: "Naturel & Glow",
  q_makeup_feel_natural_sub: "No-makeup makeup, lumineux",
  q_makeup_feel_bold_label: "Coloré & Vibrant",
  q_makeup_feel_bold_sub: "Couleurs affirmées, regard marqué",
  q_makeup_feel_smoky_label: "Smoky & Intense",
  q_makeup_feel_smoky_sub: "Regard intense, profond",
  q_makeup_feel_classic_label: "Classique & Élégant",
  q_makeup_feel_classic_sub: "Nude, rouge à lèvres, raffiné",
  season_spring: "Printemps",
  season_summer: "Été",
  season_autumn: "Automne",
  season_winter: "Hiver",
  season_spring_sub: "Warm Spring",
  season_summer_sub: "Cool Summer",
  season_autumn_sub: "Warm Autumn",
  season_winter_sub: "Cool Winter",
  season_spring_desc: "Tu irradies la chaleur et la légèreté. Ton teint est lumineux, doré ou pêche, et tes traits ont une clarté naturelle. Les couleurs qui te font briller sont chaudes, lumineuses et jamais trop saturées.",
  season_summer_desc: "Tu possèdes une beauté douce et raffinée. Ton teint a des sous-tons froids ou roses, et tu brilles dans les teintes douces, poudrées et délicatement froides.",
  season_autumn_desc: "Tu incarnes la richesse de l'automne. Ton teint est profond, doré ou olivâtre. Les couleurs sombres et terreuses t'appartiennent — elles te donnent une profondeur magnétique.",
  season_winter_desc: "Tu es faite pour les contrastes forts et les couleurs intenses. Tu brilles dans le noir, le blanc pur et les couleurs profondes et saturées.",
  you_are_a: "Tu es une",
};

const it: Translations = {
  ...en,
  hero_line1: "Scopri la tua",
  hero_accent: "palette ideale",
  app_tag: "ANALISI CROMATICA PERSONALE",
  app_tagline: "10 domande per rivelare la tua stagione cromatica, i colori makeup e la tua palette guardaroba.",
  start_quiz: "Inizia il quiz",
  retake_quiz: "Rifai il quiz",
  view_my_result: "Vedi il mio risultato",
  steps_skin: "Carnagione",
  steps_colors: "Colori",
  steps_result: "Risultato",
  question_of: "di",
  next: "Continua",
  back: "Indietro",
  reveal_colors: "Rivela i miei colori",
  palette_title: "La Tua Palette di Colori",
  palette_subtitle: "Queste tonalità si armonizzano naturalmente con la tua colorazione.",
  avoid_title: "Colori da Evitare",
  avoid_subtitle: "Queste tonalità possono spegnere il tuo splendore naturale.",
  style_section: "I Tuoi Colori Stile",
  hair_title: "Colori Capelli Consigliati",
  jewelry_title: "La Tua Palette Gioielli",
  wardrobe_title: "La Tua Palette Guardaroba",
  wardrobe_essentials: "Fondamentali",
  wardrobe_accents: "Colori Accent",
  wardrobe_neutrals: "Neutri",
  wardrobe_avoid: "Da Evitare",
  makeup_section: "La Tua Palette Makeup",
  makeup_foundation: "Fondotinta",
  makeup_corrector: "Correttore di Colore",
  makeup_concealer: "Correttore",
  makeup_blush: "Blush",
  makeup_bronzer: "Bronzer & Contouring",
  makeup_highlighter: "Illuminante",
  makeup_eye_pencil: "Matita Occhi",
  makeup_brow_pencil: "Matita Sopracciglia",
  makeup_lip_liner: "Matita Labbra",
  shop_makeup: "Shop the Makeup",
  restart_quiz: "Ricomincia il quiz",
  get_premium: "Sblocca l'Analisi Completa",
  subscribe_title: "Scegli il Tuo Piano",
  subscribe_subtitle: "Sblocca il tuo profilo completo. Impegno minimo 1 settimana.",
  most_popular: "Più Popolare",
  per_day: "/giorno",
  per_week_min: "min. 1 settimana",
  week_commitment: "Minimo 1 settimana",
  subscribe_btn: "Accedi",
  plan1_name: "Essenziali",
  plan2_name: "Stile",
  plan3_name: "Full Glam",
  auth_title_login: "Accedi",
  auth_title_register: "Crea Account",
  auth_email: "Indirizzo email",
  auth_password: "Password",
  auth_signin: "Accedi",
  auth_register: "Crea account",
  auth_switch_to_login: "Hai già un account? Accedi",
  auth_switch_to_register: "Nessun account? Creane uno",
  auth_guest: "Continua senza account",
  season_spring: "Primavera",
  season_summer: "Estate",
  season_autumn: "Autunno",
  season_winter: "Inverno",
  you_are_a: "Sei una",
};

const es: Translations = {
  ...en,
  hero_line1: "Descubre tu",
  hero_accent: "paleta ideal",
  app_tag: "ANÁLISIS DE COLOR PERSONAL",
  app_tagline: "10 preguntas para revelar tu estación cromática, colores de maquillaje y paleta de ropa.",
  start_quiz: "Empezar el test",
  retake_quiz: "Repetir el test",
  view_my_result: "Ver mi resultado",
  steps_skin: "Piel",
  steps_colors: "Colores",
  steps_result: "Resultado",
  question_of: "de",
  next: "Continuar",
  back: "Atrás",
  reveal_colors: "Revelar mis colores",
  palette_title: "Tu Paleta de Colores",
  palette_subtitle: "Estos tonos se armonizan naturalmente con tu coloración.",
  avoid_title: "Colores a Evitar",
  style_section: "Tus Colores de Estilo",
  hair_title: "Colores de Cabello Recomendados",
  jewelry_title: "Tu Paleta de Joyería",
  wardrobe_title: "Tu Paleta de Vestuario",
  wardrobe_essentials: "Básicos",
  wardrobe_accents: "Colores Accent",
  wardrobe_neutrals: "Neutros",
  wardrobe_avoid: "Evitar",
  makeup_section: "Tu Paleta de Maquillaje",
  makeup_foundation: "Base de Maquillaje",
  makeup_corrector: "Corrector de Color",
  makeup_concealer: "Corrector",
  makeup_blush: "Colorete",
  makeup_lip_liner: "Perfilador de Labios",
  shop_makeup: "Shop the Makeup",
  restart_quiz: "Repetir el test",
  get_premium: "Desbloquear Análisis Completo",
  subscribe_title: "Elige Tu Plan",
  subscribe_subtitle: "Desbloquea tu perfil completo. Compromiso mínimo 1 semana.",
  most_popular: "Más Popular",
  per_day: "/día",
  per_week_min: "mín. 1 semana",
  week_commitment: "Mínimo 1 semana",
  subscribe_btn: "Acceder",
  plan1_name: "Esenciales",
  plan2_name: "Estilo",
  plan3_name: "Full Glam",
  auth_title_login: "Iniciar Sesión",
  auth_title_register: "Crear Cuenta",
  auth_email: "Correo electrónico",
  auth_password: "Contraseña",
  auth_signin: "Iniciar sesión",
  auth_register: "Crear cuenta",
  auth_switch_to_login: "¿Ya tienes cuenta? Inicia sesión",
  auth_switch_to_register: "¿Sin cuenta? Créala",
  auth_guest: "Continuar sin cuenta",
  season_spring: "Primavera",
  season_summer: "Verano",
  season_autumn: "Otoño",
  season_winter: "Invierno",
  you_are_a: "Eres una",
};

const pt: Translations = {
  ...en,
  hero_line1: "Descubra sua",
  hero_accent: "paleta ideal",
  app_tag: "ANÁLISE DE COR PESSOAL",
  app_tagline: "10 perguntas para revelar sua estação cromática, cores de maquiagem e paleta de guarda-roupa.",
  start_quiz: "Começar o quiz",
  retake_quiz: "Refazer o quiz",
  view_my_result: "Ver meu resultado",
  steps_skin: "Pele",
  steps_colors: "Cores",
  steps_result: "Resultado",
  question_of: "de",
  next: "Continuar",
  back: "Voltar",
  reveal_colors: "Revelar minhas cores",
  palette_title: "Sua Paleta de Cores",
  avoid_title: "Cores a Evitar",
  style_section: "Suas Cores de Estilo",
  hair_title: "Cores de Cabelo Recomendadas",
  jewelry_title: "Sua Paleta de Joias",
  wardrobe_title: "Sua Paleta de Guarda-Roupa",
  wardrobe_essentials: "Básicos",
  wardrobe_accents: "Cores Accent",
  wardrobe_neutrals: "Neutros",
  wardrobe_avoid: "Evitar",
  makeup_section: "Sua Paleta de Maquiagem",
  makeup_foundation: "Base",
  makeup_corrector: "Corretor de Cor",
  makeup_concealer: "Corretivo",
  makeup_blush: "Blush",
  makeup_lip_liner: "Lápis de Lábio",
  shop_makeup: "Shop the Makeup",
  restart_quiz: "Refazer o quiz",
  get_premium: "Desbloquear Análise Completa",
  subscribe_title: "Escolha Seu Plano",
  subscribe_subtitle: "Desbloqueie seu perfil completo. Comprometimento mínimo de 1 semana.",
  most_popular: "Mais Popular",
  per_day: "/dia",
  per_week_min: "mín. 1 semana",
  week_commitment: "Mínimo 1 semana",
  subscribe_btn: "Acessar",
  plan1_name: "Essenciais",
  plan2_name: "Estilo",
  plan3_name: "Full Glam",
  auth_title_login: "Entrar",
  auth_title_register: "Criar Conta",
  auth_email: "Endereço de email",
  auth_password: "Senha",
  auth_signin: "Entrar",
  auth_register: "Criar conta",
  auth_switch_to_login: "Já tem conta? Entre",
  auth_switch_to_register: "Sem conta? Crie uma",
  auth_guest: "Continuar sem conta",
  season_spring: "Primavera",
  season_summer: "Verão",
  season_autumn: "Outono",
  season_winter: "Inverno",
  you_are_a: "Você é uma",
};

const de: Translations = {
  ...en,
  hero_line1: "Entdecke deine",
  hero_accent: "perfekte Palette",
  app_tag: "PERSÖNLICHE FARBANALYSE",
  app_tagline: "10 Fragen, um Ihre chromatische Saison, Make-up-Farben und Garderobenmuster zu enthüllen.",
  start_quiz: "Quiz starten",
  retake_quiz: "Quiz wiederholen",
  view_my_result: "Mein Ergebnis ansehen",
  steps_skin: "Teint",
  steps_colors: "Farben",
  steps_result: "Ergebnis",
  question_of: "von",
  next: "Weiter",
  back: "Zurück",
  reveal_colors: "Meine Farben enthüllen",
  palette_title: "Ihre Farbpalette",
  avoid_title: "Farben zum Vermeiden",
  style_section: "Ihre Stilfarben",
  hair_title: "Empfohlene Haarfarben",
  jewelry_title: "Ihre Schmuckpalette",
  wardrobe_title: "Ihre Garderobenpalette",
  wardrobe_essentials: "Basics",
  wardrobe_accents: "Akzentfarben",
  wardrobe_neutrals: "Neutrale",
  wardrobe_avoid: "Vermeiden",
  makeup_section: "Ihre Make-up-Palette",
  makeup_foundation: "Foundation",
  makeup_corrector: "Farbkorrektor",
  makeup_concealer: "Concealer",
  makeup_blush: "Rouge",
  makeup_lip_liner: "Lippenkonturenstift",
  shop_makeup: "Shop the Makeup",
  restart_quiz: "Quiz wiederholen",
  get_premium: "Vollständige Analyse freischalten",
  subscribe_title: "Plan Wählen",
  subscribe_subtitle: "Schalten Sie Ihr vollständiges Profil frei. Mindestlaufzeit 1 Woche.",
  most_popular: "Am Beliebtesten",
  per_day: "/Tag",
  per_week_min: "mind. 1 Woche",
  week_commitment: "Mindestens 1 Woche",
  subscribe_btn: "Zugang erhalten",
  plan1_name: "Essentials",
  plan2_name: "Stil",
  plan3_name: "Full Glam",
  auth_title_login: "Anmelden",
  auth_title_register: "Konto Erstellen",
  auth_email: "E-Mail-Adresse",
  auth_password: "Passwort",
  auth_signin: "Anmelden",
  auth_register: "Konto erstellen",
  auth_switch_to_login: "Schon ein Konto? Anmelden",
  auth_switch_to_register: "Kein Konto? Erstellen",
  auth_guest: "Ohne Konto fortfahren",
  season_spring: "Frühling",
  season_summer: "Sommer",
  season_autumn: "Herbst",
  season_winter: "Winter",
  you_are_a: "Sie sind ein",
};

export const translations: Record<Language, Translations> = { en, fr, it, es, pt, de };

import { Season } from "./quiz";

export interface ColorSwatch {
  hex: string;
  name?: string;
}

export interface SeasonData {
  badgeColor: string;
  badgeText: string;
  palette: ColorSwatch[];
  avoid: string[];
  hair: ColorSwatch[];
  jewelry: ColorSwatch[];
  wardrobe: {
    essentials: ColorSwatch[];
    accents: ColorSwatch[];
    neutrals: ColorSwatch[];
    avoid: ColorSwatch[];
  };
  makeup: {
    foundation: ColorSwatch[];
    corrector: ColorSwatch[];
    concealer: ColorSwatch[];
    blush: ColorSwatch[];
    bronzer: ColorSwatch[];
    highlighter: ColorSwatch[];
    eyePencil: ColorSwatch[];
    browPencil: ColorSwatch[];
    mascara: ColorSwatch[];
    lipLiner: ColorSwatch[];
    gloss: ColorSwatch[];
    lipstick: ColorSwatch[];
  };
}

export const seasonData: Record<Season, SeasonData> = {
  spring: {
    badgeColor: "#F5E6D0",
    badgeText: "#B8712A",
    palette: [
      { hex: "#F5C080" }, { hex: "#E8A878" }, { hex: "#F0D870" }, { hex: "#D4A870" },
      { hex: "#C8D898" }, { hex: "#F08868" }, { hex: "#E8C0A0" }, { hex: "#D4E8A0" },
      { hex: "#F0D0B8" }, { hex: "#E87840" },
    ],
    avoid: ["#0D0D0D", "#E8E8E8", "#A8A8B0", "#720018", "#1A2A50"],
    hair: [
      { hex: "#F5D080", name: "Golden Blonde" },
      { hex: "#E8C870", name: "Honey Blonde" },
      { hex: "#D4A84B", name: "Warm Caramel" },
      { hex: "#C87040", name: "Strawberry Blonde" },
      { hex: "#B87840", name: "Copper" },
      { hex: "#A86030", name: "Light Auburn" },
    ],
    jewelry: [
      { hex: "#E8B850", name: "Yellow Gold" },
      { hex: "#D4907A", name: "Rose Gold" },
      { hex: "#B86830", name: "Copper" },
      { hex: "#D4A030", name: "Bronze" },
    ],
    wardrobe: {
      essentials: [
        { hex: "#F5E0C0" }, { hex: "#D4B080" }, { hex: "#F0E8D8" }, { hex: "#C8A870" },
      ],
      accents: [
        { hex: "#F08868" }, { hex: "#5FAAB8" }, { hex: "#98C840" }, { hex: "#E87040" },
      ],
      neutrals: [
        { hex: "#C8A870" }, { hex: "#A87848" }, { hex: "#8A7058" },
      ],
      avoid: [
        { hex: "#0D0D0D" }, { hex: "#9090A0" }, { hex: "#F0F0F0" },
      ],
    },
    makeup: {
      foundation: [
        { hex: "#F5E0C8" }, { hex: "#ECD4B8" }, { hex: "#E0C0A0" }, { hex: "#D4A880" },
      ],
      corrector: [
        { hex: "#7EC8A0" }, { hex: "#E8904E" }, { hex: "#F8E868" },
      ],
      concealer: [
        { hex: "#F5E0C8" }, { hex: "#EDD8C0" }, { hex: "#E8D0B8" },
      ],
      blush: [
        { hex: "#F08868" }, { hex: "#E8A070" }, { hex: "#F5B890" }, { hex: "#E87040" },
      ],
      bronzer: [
        { hex: "#C07840" }, { hex: "#A86030" }, { hex: "#B87848" },
      ],
      highlighter: [
        { hex: "#F5D090" }, { hex: "#F0C880" }, { hex: "#F8E0A0" },
      ],
      eyePencil: [
        { hex: "#3A2010" }, { hex: "#5C3820" }, { hex: "#8B4020" }, { hex: "#2A1808" },
      ],
      browPencil: [
        { hex: "#8B6040" }, { hex: "#A07848" }, { hex: "#7A5028" },
      ],
      mascara: [
        { hex: "#1A0800" }, { hex: "#3A1808" },
      ],
      lipLiner: [
        { hex: "#C06048" }, { hex: "#D07858" }, { hex: "#B85038" },
      ],
      gloss: [
        { hex: "#F09070" }, { hex: "#E87858" }, { hex: "#F5A880" },
      ],
      lipstick: [
        { hex: "#E05838" }, { hex: "#D06848" }, { hex: "#C85030" }, { hex: "#E87040" }, { hex: "#B84030" },
      ],
    },
  },

  summer: {
    badgeColor: "#E8F0F8",
    badgeText: "#3D6878",
    palette: [
      { hex: "#B8CCE0" }, { hex: "#D0B8CC" }, { hex: "#C8D8C8" }, { hex: "#E8C8D0" },
      { hex: "#B0B8C8" }, { hex: "#D8D0C0" }, { hex: "#A8C8B8" }, { hex: "#D8B8C8" },
      { hex: "#C0D0E0" }, { hex: "#E0D8E8" },
    ],
    avoid: ["#E87040", "#F0D040", "#8B4020", "#98781A", "#F08040"],
    hair: [
      { hex: "#E8E0D0", name: "Platinum Blonde" },
      { hex: "#C8C0A8", name: "Ash Blonde" },
      { hex: "#D0C0C0", name: "Cool Light Brown" },
      { hex: "#9898B0", name: "Silver Grey" },
      { hex: "#585870", name: "Cool Dark Brown" },
      { hex: "#E8D0D8", name: "Dusty Rose Blonde" },
    ],
    jewelry: [
      { hex: "#C8D0D8", name: "Silver" },
      { hex: "#E0E8F0", name: "White Gold" },
      { hex: "#D8E0F0", name: "Platinum" },
      { hex: "#8098C8", name: "Aquamarine" },
    ],
    wardrobe: {
      essentials: [
        { hex: "#E8E0E8" }, { hex: "#B8C8D8" }, { hex: "#D8C8D8" }, { hex: "#D0E0E8" },
      ],
      accents: [
        { hex: "#C040A0" }, { hex: "#3050A8" }, { hex: "#A02858" }, { hex: "#6870C0" },
      ],
      neutrals: [
        { hex: "#909090" }, { hex: "#2A3048" }, { hex: "#C0A8B8" },
      ],
      avoid: [
        { hex: "#E87040" }, { hex: "#8B5020" }, { hex: "#C07820" },
      ],
    },
    makeup: {
      foundation: [
        { hex: "#F5E0D8" }, { hex: "#EDD8D5" }, { hex: "#E5CCC8" }, { hex: "#D8C0BC" },
      ],
      corrector: [
        { hex: "#7EC8A0" }, { hex: "#D4A8C0" }, { hex: "#C8C0D8" },
      ],
      concealer: [
        { hex: "#F5E0D8" }, { hex: "#EDD8D5" }, { hex: "#E5CCC8" },
      ],
      blush: [
        { hex: "#D0809A" }, { hex: "#E8A0B0" }, { hex: "#C870A0" }, { hex: "#D898B8" },
      ],
      bronzer: [
        { hex: "#C09080" }, { hex: "#B08070" }, { hex: "#C8A090" },
      ],
      highlighter: [
        { hex: "#F0D8E0" }, { hex: "#E8D0D8" }, { hex: "#E0D8F0" },
      ],
      eyePencil: [
        { hex: "#2A2A3A" }, { hex: "#4A4860" }, { hex: "#3A3040" }, { hex: "#484058" },
      ],
      browPencil: [
        { hex: "#6A5868" }, { hex: "#7A6870" }, { hex: "#5A4858" },
      ],
      mascara: [
        { hex: "#0A0A14" }, { hex: "#1A1828" },
      ],
      lipLiner: [
        { hex: "#8B3060" }, { hex: "#903878" }, { hex: "#984068" },
      ],
      gloss: [
        { hex: "#D0789A" }, { hex: "#E090A8" }, { hex: "#C87888" },
      ],
      lipstick: [
        { hex: "#A03060" }, { hex: "#8B2050" }, { hex: "#C04878" }, { hex: "#D85888" }, { hex: "#903068" },
      ],
    },
  },

  autumn: {
    badgeColor: "#F5EDDF",
    badgeText: "#8B4513",
    palette: [
      { hex: "#C87832" }, { hex: "#8B6040" }, { hex: "#D4A040" }, { hex: "#A8602C" },
      { hex: "#4A6830" }, { hex: "#8B4020" }, { hex: "#C09040" }, { hex: "#603820" },
      { hex: "#B87040" }, { hex: "#6A5030" },
    ],
    avoid: ["#FFB0D0", "#C8B0E0", "#F5F5F5", "#909098", "#FF80A0"],
    hair: [
      { hex: "#8B3010", name: "Warm Auburn" },
      { hex: "#7A4820", name: "Chestnut" },
      { hex: "#B06030", name: "Copper" },
      { hex: "#603820", name: "Dark Mahogany" },
      { hex: "#A86840", name: "Warm Brunette" },
      { hex: "#D48030", name: "Golden Copper" },
    ],
    jewelry: [
      { hex: "#D4A030", name: "Yellow Gold" },
      { hex: "#B87830", name: "Bronze" },
      { hex: "#C87038", name: "Copper" },
      { hex: "#A85820", name: "Amber" },
    ],
    wardrobe: {
      essentials: [
        { hex: "#C8A870" }, { hex: "#8B5820" }, { hex: "#786048" }, { hex: "#B89868" },
      ],
      accents: [
        { hex: "#C07832" }, { hex: "#C8A020" }, { hex: "#8B2010" }, { hex: "#D06020" },
      ],
      neutrals: [
        { hex: "#604030" }, { hex: "#C8B890" }, { hex: "#D0B880" },
      ],
      avoid: [
        { hex: "#F0F0F0" }, { hex: "#FFB0D0" }, { hex: "#909098" },
      ],
    },
    makeup: {
      foundation: [
        { hex: "#E8C090" }, { hex: "#D4A870" }, { hex: "#C89060" }, { hex: "#B87848" },
      ],
      corrector: [
        { hex: "#7EC8A0" }, { hex: "#E8904E" }, { hex: "#F0D870" }, { hex: "#FFB870" },
      ],
      concealer: [
        { hex: "#E8C090" }, { hex: "#D4A870" }, { hex: "#C89060" },
      ],
      blush: [
        { hex: "#B86030" }, { hex: "#A05028" }, { hex: "#C07038" }, { hex: "#983820" },
      ],
      bronzer: [
        { hex: "#8B5020" }, { hex: "#7A4018" }, { hex: "#604010" },
      ],
      highlighter: [
        { hex: "#D4A030" }, { hex: "#C89828" }, { hex: "#E8C040" }, { hex: "#B87828" },
      ],
      eyePencil: [
        { hex: "#2A1808" }, { hex: "#3A2010" }, { hex: "#602808" }, { hex: "#483018" },
      ],
      browPencil: [
        { hex: "#5C3820" }, { hex: "#7A4828" }, { hex: "#8B5830" },
      ],
      mascara: [
        { hex: "#0A0400" }, { hex: "#1A0800" },
      ],
      lipLiner: [
        { hex: "#803020" }, { hex: "#903828" }, { hex: "#7A2818" },
      ],
      gloss: [
        { hex: "#C07038" }, { hex: "#D08048" }, { hex: "#A85830" },
      ],
      lipstick: [
        { hex: "#8B3020" }, { hex: "#A04028" }, { hex: "#903830" }, { hex: "#7A2018" }, { hex: "#B04830" },
      ],
    },
  },

  winter: {
    badgeColor: "#E8EEF5",
    badgeText: "#1A2A50",
    palette: [
      { hex: "#1A1A2E" }, { hex: "#8B0038" }, { hex: "#6A0DAD" }, { hex: "#C0C8D8" },
      { hex: "#004488" }, { hex: "#F8F8F8" }, { hex: "#101010" }, { hex: "#CC0044" },
      { hex: "#3A0058" }, { hex: "#006060" },
    ],
    avoid: ["#E87040", "#8B7820", "#C8A060", "#D49030", "#C07038"],
    hair: [
      { hex: "#0D0D0D", name: "Jet Black" },
      { hex: "#282830", name: "Cool Dark Brown" },
      { hex: "#F0F0F5", name: "Platinum Blonde" },
      { hex: "#A8A8B8", name: "Silver Grey" },
      { hex: "#1A1828", name: "Deep Navy Black" },
      { hex: "#C8C0D8", name: "Icy Blonde" },
    ],
    jewelry: [
      { hex: "#D0D8E8", name: "Silver" },
      { hex: "#E8F0F8", name: "Platinum" },
      { hex: "#E0E8F8", name: "White Gold" },
      { hex: "#6060C8", name: "Sapphire" },
    ],
    wardrobe: {
      essentials: [
        { hex: "#0D0D0D" }, { hex: "#F8F8F8" }, { hex: "#808090" }, { hex: "#404050" },
      ],
      accents: [
        { hex: "#CC0044" }, { hex: "#D020A0" }, { hex: "#0044A8" }, { hex: "#6A0DAD" }, { hex: "#006848" },
      ],
      neutrals: [
        { hex: "#1A2848" }, { hex: "#484058" }, { hex: "#3A0050" },
      ],
      avoid: [
        { hex: "#C8A060" }, { hex: "#C87838" }, { hex: "#E8B840" }, { hex: "#D08820" },
      ],
    },
    makeup: {
      foundation: [
        { hex: "#F5E8E0" }, { hex: "#E8D0C8" }, { hex: "#D8B8B0" }, { hex: "#3D1808" },
      ],
      corrector: [
        { hex: "#7EC8A0" }, { hex: "#D4A8C0" }, { hex: "#A8A0D8" }, { hex: "#FFB890" },
      ],
      concealer: [
        { hex: "#F5E8E0" }, { hex: "#E8D0C8" }, { hex: "#D8B8B0" },
      ],
      blush: [
        { hex: "#901840" }, { hex: "#C03060" }, { hex: "#B04080" }, { hex: "#800030" },
      ],
      bronzer: [
        { hex: "#606070" }, { hex: "#505060" }, { hex: "#707080" },
      ],
      highlighter: [
        { hex: "#D0D8E8" }, { hex: "#C8D0E0" }, { hex: "#E0E8F8" }, { hex: "#E8E0F0" },
      ],
      eyePencil: [
        { hex: "#0A0A10" }, { hex: "#1A1828" }, { hex: "#281830" }, { hex: "#1A0818" },
      ],
      browPencil: [
        { hex: "#202028" }, { hex: "#2A2838" }, { hex: "#3A3848" },
      ],
      mascara: [
        { hex: "#000000" }, { hex: "#080820" },
      ],
      lipLiner: [
        { hex: "#600020" }, { hex: "#800030" }, { hex: "#500818" },
      ],
      gloss: [
        { hex: "#9B1035" }, { hex: "#A81840" }, { hex: "#801028" },
      ],
      lipstick: [
        { hex: "#700020" }, { hex: "#8B0028" }, { hex: "#A01038" }, { hex: "#600018" }, { hex: "#C02040" },
      ],
    },
  },
};

const colors = {
  light: {
    text: "#0D0D0D",
    tint: "#C9A96E",

    background: "#F5F0EB",
    foreground: "#0D0D0D",

    card: "#FFFFFF",
    cardForeground: "#0D0D0D",

    primary: "#0D0D0D",
    primaryForeground: "#FFFFFF",

    secondary: "#EDE9E3",
    secondaryForeground: "#3D3730",

    muted: "#F2EEE9",
    mutedForeground: "#8C8680",

    accent: "#C9A96E",
    accentForeground: "#FFFFFF",
    accentRose: "#D4918A",

    softInk: "#3D3730",

    destructive: "#B8463B",
    destructiveForeground: "#FFFFFF",

    border: "#E5E0DB",
    input: "#E5E0DB",

    gold: "#C9A96E",
    rose: "#D4918A",
  },

  radius: 14,
};

export default colors;

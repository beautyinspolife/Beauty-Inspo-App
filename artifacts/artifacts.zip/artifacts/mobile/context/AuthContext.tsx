import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useState } from "react";

const USERS_KEY = "@palette_users";
const SESSION_KEY = "@palette_session";

interface User {
  email: string;
  passwordHash: string;
}

interface Session {
  email: string;
}

interface AuthContextValue {
  user: Session | null;
  isGuest: boolean;
  register: (email: string, password: string) => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  continueAsGuest: () => void;
}

function simpleHash(s: string): string {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
  }
  return String(h);
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<Session | null>(null);
  const [isGuest, setIsGuest] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(SESSION_KEY).then((val) => {
      if (val) {
        try { setUser(JSON.parse(val)); } catch {}
      }
    });
  }, []);

  const getUsers = async (): Promise<User[]> => {
    const raw = await AsyncStorage.getItem(USERS_KEY);
    if (!raw) return [];
    try { return JSON.parse(raw); } catch { return []; }
  };

  const register = useCallback(async (email: string, password: string) => {
    const users = await getUsers();
    const exists = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (exists) throw new Error("email_taken");
    const newUser: User = { email: email.toLowerCase(), passwordHash: simpleHash(password) };
    await AsyncStorage.setItem(USERS_KEY, JSON.stringify([...users, newUser]));
    const session: Session = { email: newUser.email };
    await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(session));
    setUser(session);
    setIsGuest(false);
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const users = await getUsers();
    const found = users.find(
      (u) => u.email.toLowerCase() === email.toLowerCase() && u.passwordHash === simpleHash(password)
    );
    if (!found) throw new Error("invalid");
    const session: Session = { email: found.email };
    await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(session));
    setUser(session);
    setIsGuest(false);
  }, []);

  const logout = useCallback(async () => {
    await AsyncStorage.removeItem(SESSION_KEY);
    setUser(null);
    setIsGuest(false);
  }, []);

  const continueAsGuest = useCallback(() => {
    setIsGuest(true);
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider value={{ user, isGuest, register, login, logout, continueAsGuest }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}

import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useState } from "react";

import { Season, computeSeason, questions } from "@/data/quiz";

const STORAGE_KEY = "@palette_quiz_result";

interface QuizContextValue {
  currentIndex: number;
  answers: Record<string, string>;
  result: Season | null;
  savedResult: Season | null;
  setAnswer: (questionId: string, value: string) => void;
  goNext: () => void;
  goBack: () => void;
  finishQuiz: () => void;
  resetQuiz: () => void;
  loadSavedResult: () => void;
}

const QuizContext = createContext<QuizContextValue | null>(null);

export function QuizProvider({ children }: { children: React.ReactNode }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [result, setResult] = useState<Season | null>(null);
  const [savedResult, setSavedResult] = useState<Season | null>(null);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((val) => {
      if (val) setSavedResult(val as Season);
    });
  }, []);

  const setAnswer = useCallback((questionId: string, value: string) => {
    setAnswers((prev) => ({ ...prev, [questionId]: value }));
  }, []);

  const goNext = useCallback(() => {
    if (currentIndex < questions.length - 1) setCurrentIndex((i) => i + 1);
  }, [currentIndex]);

  const goBack = useCallback(() => {
    if (currentIndex > 0) setCurrentIndex((i) => i - 1);
  }, [currentIndex]);

  const finishQuiz = useCallback(() => {
    const season = computeSeason(answers);
    setResult(season);
    setSavedResult(season);
    AsyncStorage.setItem(STORAGE_KEY, season);
  }, [answers]);

  const resetQuiz = useCallback(() => {
    setCurrentIndex(0);
    setAnswers({});
    setResult(null);
  }, []);

  const loadSavedResult = useCallback(() => {
    if (savedResult) setResult(savedResult);
  }, [savedResult]);

  return (
    <QuizContext.Provider value={{ currentIndex, answers, result, savedResult, setAnswer, goNext, goBack, finishQuiz, resetQuiz, loadSavedResult }}>
      {children}
    </QuizContext.Provider>
  );
}

export function useQuiz() {
  const ctx = useContext(QuizContext);
  if (!ctx) throw new Error("useQuiz must be used within QuizProvider");
  return ctx;
}

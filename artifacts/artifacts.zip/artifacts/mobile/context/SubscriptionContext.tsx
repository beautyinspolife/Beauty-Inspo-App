import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useState } from "react";

export type SubscriptionTier = 0 | 1 | 2 | 3;

const STORAGE_KEY = "@palette_subscription_tier";

interface SubscriptionContextValue {
  tier: SubscriptionTier;
  subscribe: (tier: SubscriptionTier) => Promise<void>;
  hasAccess: (requiredTier: SubscriptionTier) => boolean;
}

const SubscriptionContext = createContext<SubscriptionContextValue | null>(null);

export function SubscriptionProvider({ children }: { children: React.ReactNode }) {
  const [tier, setTier] = useState<SubscriptionTier>(0);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((val) => {
      if (val) setTier(Number(val) as SubscriptionTier);
    });
  }, []);

  const subscribe = useCallback(async (newTier: SubscriptionTier) => {
    setTier(newTier);
    await AsyncStorage.setItem(STORAGE_KEY, String(newTier));
  }, []);

  const hasAccess = useCallback(
    (requiredTier: SubscriptionTier) => tier >= requiredTier,
    [tier]
  );

  return (
    <SubscriptionContext.Provider value={{ tier, subscribe, hasAccess }}>
      {children}
    </SubscriptionContext.Provider>
  );
}

export function useSubscription() {
  const ctx = useContext(SubscriptionContext);
  if (!ctx) throw new Error("useSubscription must be used within SubscriptionProvider");
  return ctx;
}

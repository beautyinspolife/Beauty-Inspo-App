import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import React, { useEffect, useRef } from "react";
import {
  Animated,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useLanguage } from "@/context/LanguageContext";
import { useQuiz } from "@/context/QuizContext";
import { seasonData } from "@/data/seasonData";
import { useColors } from "@/hooks/useColors";

const WELCOME_SWATCHES = [
  "#F5C080", "#D0B8CC", "#C87832", "#C0C8D8",
  "#E8A878", "#8B3010", "#1A1A2E", "#D4A040",
];

export default function WelcomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { t } = useLanguage();
  const { savedResult, loadSavedResult, resetQuiz } = useQuiz();

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(24)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 700, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 700, useNativeDriver: true }),
    ]).start();
  }, []);

  const topInset = Platform.OS === "web" ? 67 : insets.top;
  const bottomInset = Platform.OS === "web" ? 34 : insets.bottom;

  const handleStart = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    resetQuiz();
    router.push("/quiz");
  };

  const handleViewResult = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    loadSavedResult();
    router.push("/result");
  };

  const savedProfile = savedResult ? seasonData[savedResult] : null;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <TouchableOpacity
        style={[styles.langBtn, { top: topInset + 16 }]}
        onPress={() => router.push("/language")}
        hitSlop={12}
      >
        <Text style={[styles.langBtnText, { color: colors.mutedForeground }]}>
          🌐
        </Text>
      </TouchableOpacity>

      <Animated.View
        style={[
          styles.content,
          {
            paddingTop: topInset + 60,
            paddingBottom: bottomInset + 32,
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
          },
        ]}
      >
        <View style={styles.swatchRow}>
          {WELCOME_SWATCHES.map((hex, i) => (
            <View
              key={i}
              style={[
                styles.swatch,
                {
                  backgroundColor: hex,
                  width: i % 3 === 0 ? 52 : 40,
                  height: i % 3 === 0 ? 52 : 40,
                  borderRadius: i % 3 === 0 ? 26 : 20,
                },
              ]}
            />
          ))}
        </View>

        <View style={styles.textBlock}>
          <Text style={[styles.tag, { color: colors.accent }]}>
            {t("app_tag")}
          </Text>
          <Text style={[styles.title, { color: colors.foreground }]}>
            {t("hero_line1") + "\n"}
            <Text style={[styles.titleItalic, { color: colors.accent }]}>
              {t("hero_accent")}
            </Text>
          </Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            {t("app_tagline")}
          </Text>
        </View>

        <View style={styles.actions}>
          <Pressable
            onPress={handleStart}
            style={({ pressed }) => [
              styles.primaryBtn,
              {
                backgroundColor: colors.primary,
                opacity: pressed ? 0.8 : 1,
                transform: [{ scale: pressed ? 0.98 : 1 }],
              },
            ]}
          >
            <Text style={[styles.primaryBtnText, { color: colors.primaryForeground }]}>
              {savedResult ? t("retake_quiz") : t("start_quiz")}
            </Text>
          </Pressable>

          {savedResult && savedProfile && (
            <Pressable
              onPress={handleViewResult}
              style={({ pressed }) => [
                styles.secondaryBtn,
                {
                  borderColor: colors.border,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <View style={styles.savedResultRow}>
                <View
                  style={[
                    styles.savedSwatch,
                    { backgroundColor: savedProfile.palette[0]?.hex ?? "#ccc" },
                  ]}
                />
                <View
                  style={[
                    styles.savedSwatch,
                    { backgroundColor: savedProfile.palette[2]?.hex ?? "#ccc" },
                  ]}
                />
                <View
                  style={[
                    styles.savedSwatch,
                    { backgroundColor: savedProfile.palette[5]?.hex ?? "#ccc" },
                  ]}
                />
                <Text style={[styles.secondaryBtnText, { color: colors.softInk as string }]}>
                  {t("view_my_result")}
                </Text>
              </View>
            </Pressable>
          )}
        </View>

        <View style={styles.stepsRow}>
          {([t("steps_skin"), t("steps_colors"), t("steps_result")] as string[]).map((step, i) => (
            <View key={i} style={styles.stepItem}>
              <View style={[styles.stepDot, { backgroundColor: colors.accent }]} />
              <Text style={[styles.stepLabel, { color: colors.mutedForeground }]}>
                {step}
              </Text>
            </View>
          ))}
        </View>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  langBtn: {
    position: "absolute",
    right: 24,
    zIndex: 10,
    padding: 8,
  },
  langBtnText: { fontSize: 20 },
  content: {
    flex: 1,
    paddingHorizontal: 28,
    justifyContent: "space-between",
  },
  swatchRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
    marginBottom: 32,
  },
  swatch: {
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  textBlock: { marginBottom: 36 },
  tag: {
    fontSize: 10,
    fontFamily: "Inter_600SemiBold",
    letterSpacing: 2.5,
    marginBottom: 16,
  },
  title: {
    fontSize: 38,
    fontFamily: "Inter_400Regular",
    lineHeight: 46,
    marginBottom: 14,
  },
  titleItalic: {
    fontStyle: "italic",
    fontFamily: "Inter_400Regular",
  },
  subtitle: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    lineHeight: 22,
  },
  actions: { gap: 12, marginBottom: 28 },
  primaryBtn: {
    borderRadius: 12,
    paddingVertical: 18,
    alignItems: "center",
  },
  primaryBtnText: {
    fontSize: 15,
    fontFamily: "Inter_500Medium",
    letterSpacing: 0.2,
  },
  secondaryBtn: {
    borderWidth: 1,
    borderRadius: 12,
    paddingVertical: 14,
    paddingHorizontal: 20,
    alignItems: "center",
  },
  savedResultRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  savedSwatch: {
    width: 16,
    height: 16,
    borderRadius: 8,
  },
  secondaryBtnText: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
  },
  stepsRow: {
    flexDirection: "row",
    gap: 24,
    justifyContent: "center",
  },
  stepItem: { alignItems: "center", gap: 6 },
  stepDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    opacity: 0.4,
  },
  stepLabel: {
    fontSize: 10,
    fontFamily: "Inter_400Regular",
    letterSpacing: 0.8,
  },
});

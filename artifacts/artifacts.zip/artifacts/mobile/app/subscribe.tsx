import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import React, { useState } from "react";
import {
  ActivityIndicator,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAuth } from "@/context/AuthContext";
import { useLanguage } from "@/context/LanguageContext";
import { useSubscription, SubscriptionTier } from "@/context/SubscriptionContext";
import { useColors } from "@/hooks/useColors";

const PLANS = [
  {
    tier: 1 as SubscriptionTier,
    priceKey: "0.99",
    nameKey: "plan1_name",
    features: ["plan1_feature1", "plan1_feature2"],
    accent: "#C9A96E",
  },
  {
    tier: 2 as SubscriptionTier,
    priceKey: "1.29",
    nameKey: "plan2_name",
    features: ["plan2_feature1", "plan2_feature2", "plan2_feature3", "plan2_feature4"],
    accent: "#0D0D0D",
    popular: true,
  },
  {
    tier: 3 as SubscriptionTier,
    priceKey: "3.29",
    nameKey: "plan3_name",
    features: ["plan3_feature1", "plan3_feature2", "plan3_feature3"],
    accent: "#D4918A",
  },
];

export default function SubscribeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { t } = useLanguage();
  const { user, isGuest } = useAuth();
  const { subscribe, tier: currentTier } = useSubscription();
  const [loading, setLoading] = useState<SubscriptionTier | null>(null);
  const [confirmTier, setConfirmTier] = useState<SubscriptionTier | null>(null);

  const topInset = Platform.OS === "web" ? 67 : insets.top;
  const bottomInset = Platform.OS === "web" ? 34 : insets.bottom;

  const handleSelectPlan = (tier: SubscriptionTier) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    if (!user && !isGuest) {
      router.push({ pathname: "/auth", params: { returnTo: "subscribe", tier: String(tier) } });
      return;
    }
    setConfirmTier(tier);
  };

  const handleConfirmPurchase = async () => {
    if (!confirmTier) return;
    setLoading(confirmTier);
    setConfirmTier(null);
    await new Promise((r) => setTimeout(r, 1200));
    await subscribe(confirmTier);
    setLoading(null);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    router.back();
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.topBar, { paddingTop: topInset + 12 }]}>
        <TouchableOpacity onPress={() => router.back()} hitSlop={12}>
          <Text style={[styles.backArrow, { color: colors.mutedForeground }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.topTitle, { color: colors.mutedForeground }]}>Premium</Text>
        <View style={{ width: 28 }} />
      </View>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={{ paddingHorizontal: 18, paddingBottom: bottomInset + 32, gap: 20 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={[styles.title, { color: colors.foreground }]}>
            {t("subscribe_title")}
          </Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            {t("subscribe_subtitle")}
          </Text>
        </View>

        <View style={styles.plansRow}>
          {PLANS.map((plan, idx) => {
            const isPop = plan.popular;
            const isActive = currentTier >= plan.tier;
            return (
              <View
                key={plan.tier}
                style={[
                  styles.planCard,
                  {
                    backgroundColor: isPop ? colors.foreground : colors.card,
                    borderColor: isPop ? colors.foreground : colors.border,
                    flex: isPop ? 1.15 : 1,
                    transform: [{ scale: isPop ? 1.03 : 1 }],
                    zIndex: isPop ? 2 : 1,
                  },
                ]}
              >
                {isPop && (
                  <View style={styles.popularBadge}>
                    <Text style={styles.popularBadgeText}>{t("most_popular")}</Text>
                  </View>
                )}

                <Text style={[styles.planName, { color: isPop ? "#FFFFFF" : colors.foreground }]}>
                  {t(plan.nameKey as any)}
                </Text>

                <View style={styles.priceBlock}>
                  <Text style={[styles.price, { color: isPop ? "#FFFFFF" : colors.foreground }]}>
                    ${plan.priceKey}
                  </Text>
                  <Text style={[styles.perDay, { color: isPop ? "rgba(255,255,255,0.5)" : colors.mutedForeground }]}>
                    {t("per_day")}
                  </Text>
                  <Text style={[styles.minWeek, { color: isPop ? "rgba(255,255,255,0.35)" : colors.mutedForeground }]}>
                    {t("per_week_min")}
                  </Text>
                </View>

                <View style={styles.divider} />

                {plan.features.map((fk, fi) => (
                  <View key={fi} style={styles.featureRow}>
                    <Text style={[styles.featureCheck, { color: isPop ? "#C9A96E" : colors.accent }]}>✓</Text>
                    <Text style={[styles.featureText, { color: isPop ? "rgba(255,255,255,0.8)" : colors.softInk as string }]}>
                      {t(fk as any)}
                    </Text>
                  </View>
                ))}

                <Pressable
                  onPress={() => !isActive && handleSelectPlan(plan.tier)}
                  disabled={isActive || loading !== null}
                  style={({ pressed }) => [
                    styles.planBtn,
                    {
                      backgroundColor: isPop ? "#C9A96E" : colors.foreground,
                      opacity: (isActive || loading !== null) ? 0.5 : pressed ? 0.85 : 1,
                      marginTop: "auto",
                    },
                  ]}
                >
                  {loading === plan.tier ? (
                    <ActivityIndicator color="#fff" size="small" />
                  ) : (
                    <Text style={styles.planBtnText}>
                      {isActive ? "✓ Active" : t("subscribe_btn")}
                    </Text>
                  )}
                </Pressable>
              </View>
            );
          })}
        </View>

        <Text style={[styles.commitment, { color: colors.mutedForeground }]}>
          {t("week_commitment")} · {t("restore")}
        </Text>
      </ScrollView>

      {/* Confirmation Modal */}
      <Modal
        visible={confirmTier !== null}
        transparent
        animationType="fade"
        onRequestClose={() => setConfirmTier(null)}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.modalCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>
              Confirm Purchase
            </Text>
            <Text style={[styles.modalBody, { color: colors.mutedForeground }]}>
              {confirmTier !== null && `${PLANS.find(p => p.tier === confirmTier)?.nameKey ? t(PLANS.find(p => p.tier === confirmTier)!.nameKey as any) : ""} · $${PLANS.find(p => p.tier === confirmTier)?.priceKey}/day`}
              {"\n"}Minimum 1 week commitment.
            </Text>
            <View style={styles.modalBtns}>
              <Pressable
                onPress={() => setConfirmTier(null)}
                style={[styles.modalBtnSecondary, { borderColor: colors.border }]}
              >
                <Text style={[styles.modalBtnSecText, { color: colors.mutedForeground }]}>Cancel</Text>
              </Pressable>
              <Pressable
                onPress={handleConfirmPurchase}
                style={[styles.modalBtnPrimary, { backgroundColor: colors.foreground }]}
              >
                <Text style={styles.modalBtnPriText}>Confirm</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 24,
    paddingBottom: 12,
  },
  backArrow: { fontSize: 22 },
  topTitle: { fontSize: 12, fontFamily: "Inter_400Regular", letterSpacing: 1.5 },
  scroll: { flex: 1 },
  header: { paddingTop: 8, alignItems: "center", gap: 8 },
  title: { fontSize: 24, fontFamily: "Inter_600SemiBold", textAlign: "center" },
  subtitle: { fontSize: 13, fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 20 },
  plansRow: {
    flexDirection: "row",
    gap: 8,
    alignItems: "flex-start",
  },
  planCard: {
    borderRadius: 18,
    borderWidth: 1,
    padding: 16,
    minHeight: 360,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 2,
    gap: 6,
  },
  popularBadge: {
    backgroundColor: "#C9A96E",
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 100,
    alignSelf: "center",
    marginBottom: 4,
  },
  popularBadgeText: { color: "#FFFFFF", fontSize: 9, fontFamily: "Inter_600SemiBold", letterSpacing: 0.5 },
  planName: { fontSize: 13, fontFamily: "Inter_600SemiBold", textAlign: "center" },
  priceBlock: { alignItems: "center", gap: 2 },
  price: { fontSize: 22, fontFamily: "Inter_700Bold", textAlign: "center" },
  perDay: { fontSize: 10, fontFamily: "Inter_400Regular", textAlign: "center" },
  minWeek: { fontSize: 9, fontFamily: "Inter_400Regular", textAlign: "center" },
  divider: { height: 1, backgroundColor: "rgba(0,0,0,0.08)", marginVertical: 8 },
  featureRow: { flexDirection: "row", gap: 6, alignItems: "flex-start" },
  featureCheck: { fontSize: 11, fontFamily: "Inter_700Bold", marginTop: 1 },
  featureText: { fontSize: 10, fontFamily: "Inter_400Regular", flex: 1, lineHeight: 15 },
  planBtn: {
    borderRadius: 10,
    paddingVertical: 12,
    alignItems: "center",
    marginTop: 12,
  },
  planBtnText: { color: "#FFFFFF", fontSize: 12, fontFamily: "Inter_600SemiBold" },
  commitment: { fontSize: 11, fontFamily: "Inter_400Regular", textAlign: "center" },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center",
    alignItems: "center",
    padding: 32,
  },
  modalCard: {
    borderRadius: 20,
    borderWidth: 1,
    padding: 28,
    width: "100%",
    gap: 16,
  },
  modalTitle: { fontSize: 18, fontFamily: "Inter_600SemiBold", textAlign: "center" },
  modalBody: { fontSize: 14, fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 22 },
  modalBtns: { flexDirection: "row", gap: 12 },
  modalBtnSecondary: {
    flex: 1,
    borderWidth: 1,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: "center",
  },
  modalBtnSecText: { fontSize: 14, fontFamily: "Inter_400Regular" },
  modalBtnPrimary: {
    flex: 1,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: "center",
  },
  modalBtnPriText: { color: "#FFFFFF", fontSize: 14, fontFamily: "Inter_500Medium" },
});

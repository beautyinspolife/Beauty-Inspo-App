import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import React, { useEffect, useRef } from "react";
import {
  Animated,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useLanguage } from "@/context/LanguageContext";
import { useQuiz } from "@/context/QuizContext";
import { questions } from "@/data/quiz";
import { useColors } from "@/hooks/useColors";

export default function QuizScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { t } = useLanguage();
  const { currentIndex, answers, setAnswer, goNext, goBack, finishQuiz } = useQuiz();

  const question = questions[currentIndex];
  const selectedValue = answers[question.id];
  const progress = (currentIndex + 1) / questions.length;
  const isLast = currentIndex === questions.length - 1;

  const fadeAnim = useRef(new Animated.Value(1)).current;
  const progressWidth = useRef(new Animated.Value(progress)).current;

  useEffect(() => {
    Animated.timing(progressWidth, {
      toValue: (currentIndex + 1) / questions.length,
      duration: 400,
      useNativeDriver: false,
    }).start();
  }, [currentIndex]);

  const animateTransition = (cb: () => void) => {
    Animated.timing(fadeAnim, { toValue: 0, duration: 120, useNativeDriver: true }).start(() => {
      cb();
      Animated.timing(fadeAnim, { toValue: 1, duration: 220, useNativeDriver: true }).start();
    });
  };

  const handleSelect = (value: string) => {
    Haptics.selectionAsync();
    setAnswer(question.id, value);
  };

  const handleNext = () => {
    if (!selectedValue) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    if (isLast) {
      finishQuiz();
      router.replace("/result");
    } else {
      animateTransition(goNext);
    }
  };

  const handleBack = () => {
    if (currentIndex === 0) { router.back(); return; }
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    animateTransition(goBack);
  };

  const topInset = Platform.OS === "web" ? 67 : insets.top;
  const bottomInset = Platform.OS === "web" ? 34 : insets.bottom;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.topBar, { paddingTop: topInset + 12 }]}>
        <TouchableOpacity onPress={handleBack} hitSlop={12} style={styles.backBtn}>
          <Text style={[styles.backArrow, { color: colors.mutedForeground }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.progressLabel, { color: colors.mutedForeground }]}>
          {currentIndex + 1} {t("question_of")} {questions.length}
        </Text>
      </View>

      <View style={styles.progressWrap}>
        <View style={[styles.progressTrack, { backgroundColor: colors.border }]}>
          <Animated.View
            style={[
              styles.progressFill,
              {
                backgroundColor: colors.foreground,
                width: progressWidth.interpolate({
                  inputRange: [0, 1],
                  outputRange: ["0%", "100%"],
                }),
              },
            ]}
          />
        </View>
      </View>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={{ paddingHorizontal: 20, paddingTop: 8, paddingBottom: bottomInset + 110 }}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <Animated.View style={{ opacity: fadeAnim }}>
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.qNumber, { color: colors.accent }]}>
              {question.number}
            </Text>
            <Text style={[styles.qText, { color: colors.foreground }]}>
              {t(question.textKey as any)}
            </Text>
            <Text style={[styles.qHint, { color: colors.mutedForeground }]}>
              {t(question.hintKey as any)}
            </Text>

            <View style={styles.options}>
              {question.options.map((opt) => {
                const selected = selectedValue === opt.value;
                return (
                  <Pressable
                    key={opt.value}
                    onPress={() => handleSelect(opt.value)}
                    style={({ pressed }) => [
                      styles.optionBtn,
                      {
                        backgroundColor: selected ? `${colors.foreground}08` : colors.card,
                        borderColor: selected ? colors.foreground : colors.border,
                        opacity: pressed ? 0.8 : 1,
                      },
                    ]}
                  >
                    <View style={[styles.swatch, { backgroundColor: opt.swatch }]} />
                    <View style={styles.optionTextBlock}>
                      <Text style={[styles.optionLabel, { color: colors.foreground }]}>
                        {t(opt.labelKey as any)}
                      </Text>
                      <Text style={[styles.optionSub, { color: colors.mutedForeground }]}>
                        {t(opt.sublabelKey as any)}
                      </Text>
                    </View>
                    {selected && (
                      <View style={[styles.checkDot, { backgroundColor: colors.foreground }]} />
                    )}
                  </Pressable>
                );
              })}
            </View>
          </View>
        </Animated.View>
      </ScrollView>

      <View
        style={[
          styles.footer,
          {
            paddingBottom: bottomInset + 16,
            backgroundColor: colors.background,
            borderTopColor: colors.border,
          },
        ]}
      >
        <Pressable
          onPress={handleNext}
          disabled={!selectedValue}
          style={({ pressed }) => [
            styles.nextBtn,
            {
              backgroundColor: selectedValue ? colors.primary : colors.border,
              opacity: pressed ? 0.85 : 1,
            },
          ]}
        >
          <Text style={[styles.nextBtnText, { color: selectedValue ? colors.primaryForeground : colors.mutedForeground }]}>
            {isLast ? t("reveal_colors") : t("next")}
          </Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  topBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 24,
    paddingBottom: 14,
  },
  backBtn: { padding: 4 },
  backArrow: { fontSize: 22 },
  progressLabel: { fontSize: 13, fontFamily: "Inter_400Regular", letterSpacing: 0.5 },
  progressWrap: { paddingHorizontal: 24, marginBottom: 20 },
  progressTrack: { height: 1.5, borderRadius: 1, overflow: "hidden" },
  progressFill: { height: "100%", borderRadius: 1 },
  scroll: { flex: 1 },
  card: {
    borderRadius: 18,
    borderWidth: 1,
    padding: 22,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 12,
    elevation: 1,
  },
  qNumber: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
    letterSpacing: 2,
    marginBottom: 10,
  },
  qText: {
    fontSize: 19,
    fontFamily: "Inter_400Regular",
    lineHeight: 27,
    marginBottom: 8,
  },
  qHint: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    fontStyle: "italic",
    lineHeight: 18,
    marginBottom: 22,
  },
  options: { gap: 8 },
  optionBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
    padding: 14,
    borderRadius: 10,
    borderWidth: 1.5,
  },
  swatch: {
    width: 28,
    height: 28,
    borderRadius: 14,
    flexShrink: 0,
    borderWidth: 2,
    borderColor: "rgba(255,255,255,0.6)",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  optionTextBlock: { flex: 1 },
  optionLabel: { fontSize: 14, fontFamily: "Inter_400Regular", marginBottom: 2 },
  optionSub: { fontSize: 11, fontFamily: "Inter_400Regular" },
  checkDot: { width: 8, height: 8, borderRadius: 4 },
  footer: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    paddingTop: 12,
    paddingHorizontal: 20,
    borderTopWidth: 1,
  },
  nextBtn: {
    borderRadius: 12,
    paddingVertical: 18,
    alignItems: "center",
  },
  nextBtnText: { fontSize: 15, fontFamily: "Inter_500Medium", letterSpacing: 0.2 },
});

import * as Haptics from "expo-haptics";
import { BlurView } from "expo-blur";
import { LinearGradient } from "expo-linear-gradient";
import * as Linking from "expo-linking";
import { useRouter } from "expo-router";
import React, { useEffect, useRef } from "react";
import {
  Animated,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useLanguage } from "@/context/LanguageContext";
import { useQuiz } from "@/context/QuizContext";
import { useSubscription } from "@/context/SubscriptionContext";
import { seasonData } from "@/data/seasonData";
import { Season } from "@/data/quiz";
import { useColors } from "@/hooks/useColors";

const SHOP_URL = "https://beautyinspo.netlify.app/";

const SEASON_KEY_MAP: Record<Season, { name: string; sub: string; desc: string }> = {
  spring: { name: "season_spring", sub: "season_spring_sub", desc: "season_spring_desc" },
  summer: { name: "season_summer", sub: "season_summer_sub", desc: "season_summer_desc" },
  autumn: { name: "season_autumn", sub: "season_autumn_sub", desc: "season_autumn_desc" },
  winter: { name: "season_winter", sub: "season_winter_sub", desc: "season_winter_desc" },
};

export default function ResultScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { t } = useLanguage();
  const { result, resetQuiz } = useQuiz();
  const { hasAccess } = useSubscription();

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 600, useNativeDriver: true }),
    ]).start();
  }, []);

  const topInset = Platform.OS === "web" ? 67 : insets.top;
  const bottomInset = Platform.OS === "web" ? 34 : insets.bottom;

  if (!result) {
    return (
      <View style={[styles.container, styles.centered, { backgroundColor: colors.background }]}>
        <Text style={[styles.errText, { color: colors.mutedForeground }]}>No result found.</Text>
        <Pressable onPress={() => router.replace("/")} style={styles.errBtn}>
          <Text style={[styles.errBtnText, { color: colors.foreground }]}>← Back</Text>
        </Pressable>
      </View>
    );
  }

  const profile = seasonData[result];
  const keys = SEASON_KEY_MAP[result];
  const canStyle = hasAccess(2);
  const canMakeup = hasAccess(3);

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.topBar, { paddingTop: topInset + 12 }]}>
        <TouchableOpacity onPress={() => router.replace("/")} hitSlop={12}>
          <Text style={[styles.backArrow, { color: colors.mutedForeground }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.topTitle, { color: colors.mutedForeground }]}>
          {t("your_season_title")}
        </Text>
        <View style={{ width: 28 }} />
      </View>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[styles.scrollContent, { paddingBottom: bottomInset + 40 }]}
        showsVerticalScrollIndicator={false}
      >
        <Animated.View style={{ opacity: fadeAnim, transform: [{ translateY: slideAnim }] }}>

          {/* HERO */}
          <View style={styles.hero}>
            <View style={[styles.badge, { backgroundColor: profile.badgeColor }]}>
              <Text style={[styles.badgeText, { color: profile.badgeText }]}>
                {t(keys.sub as any).toUpperCase()}
              </Text>
            </View>
            <Text style={[styles.heroTitle, { color: colors.foreground }]}>
              {t("you_are_a")}{" "}
              <Text style={[styles.heroSeason, { color: profile.badgeText }]}>
                {t(keys.name as any)}
              </Text>
            </Text>
            <Text style={[styles.heroDesc, { color: colors.softInk as string }]}>
              {t(keys.desc as any)}
            </Text>
          </View>

          {/* PALETTE */}
          <Section title={t("palette_title")} subtitle={t("palette_subtitle")} colors={colors}>
            <View style={styles.swatchGrid}>
              {profile.palette.map((c, i) => (
                <View key={i} style={[styles.paletteSwatch, { backgroundColor: c.hex }]} />
              ))}
            </View>
          </Section>

          {/* AVOID */}
          <Section title={t("avoid_title")} subtitle={t("avoid_subtitle")} colors={colors}>
            <View style={styles.swatchRow}>
              {(profile.avoid as string[]).map((hex, i) => (
                <View key={i} style={styles.avoidChip}>
                  <View style={[styles.avoidSwatch, { backgroundColor: hex }]} />
                  <View style={[styles.avoidX]} >
                    <Text style={styles.avoidXText}>✕</Text>
                  </View>
                </View>
              ))}
            </View>
          </Section>

          {/* PREMIUM CTA (if not subscribed to tier 2+) */}
          {!canStyle && (
            <Pressable
              onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); router.push("/subscribe"); }}
              style={({ pressed }) => [{ opacity: pressed ? 0.9 : 1 }]}
            >
              <LinearGradient
                colors={["#1A1A1A", "#3D3730"]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={styles.premiumBanner}
              >
                <Text style={styles.premiumBannerTitle}>{t("get_premium")}</Text>
                <Text style={styles.premiumBannerSub}>{t("get_premium_subtitle")}</Text>
                <View style={styles.premiumBannerBtn}>
                  <Text style={styles.premiumBannerBtnText}>Voir les offres →</Text>
                </View>
              </LinearGradient>
            </Pressable>
          )}

          {/* STYLE SECTION — blurred if no tier 2 */}
          <BlurredSection
            title={t("style_section")}
            subtitle={t("style_subtitle")}
            locked={!canStyle}
            onUnlock={() => router.push("/subscribe")}
            unlockLabel={t("unlock_to_see")}
            colors={colors}
          >
            {/* HAIR */}
            <SubSection title={t("hair_title")} subtitle={t("hair_subtitle")} colors={colors}>
              <View style={styles.swatchRow}>
                {profile.hair.map((c, i) => (
                  <View key={i} style={styles.labeledSwatch}>
                    <View style={[styles.hairSwatch, { backgroundColor: c.hex }]} />
                    {c.name && (
                      <Text style={[styles.swatchLabel, { color: colors.mutedForeground }]} numberOfLines={2}>
                        {c.name}
                      </Text>
                    )}
                  </View>
                ))}
              </View>
            </SubSection>

            {/* JEWELRY */}
            <SubSection title={t("jewelry_title")} subtitle={t("jewelry_subtitle")} colors={colors}>
              <View style={styles.swatchRow}>
                {profile.jewelry.map((c, i) => (
                  <View key={i} style={styles.labeledSwatch}>
                    <View style={[styles.jewelrySwatch, { backgroundColor: c.hex }]} />
                    {c.name && (
                      <Text style={[styles.swatchLabel, { color: colors.mutedForeground }]} numberOfLines={2}>
                        {c.name}
                      </Text>
                    )}
                  </View>
                ))}
              </View>
            </SubSection>

            {/* WARDROBE — all 4 seasons */}
            <SubSection title={t("wardrobe_title")} subtitle="" colors={colors}>
              {(["spring", "summer", "autumn", "winter"] as Season[]).map((s) => {
                const sd = seasonData[s];
                const seasonLabel = t(SEASON_KEY_MAP[s].name as any);
                return (
                  <View key={s} style={[styles.wardrobeSeasonBlock, { borderColor: colors.border }]}>
                    <Text style={[styles.wardrobeSeasonTitle, { color: colors.foreground }]}>
                      {seasonLabel.toUpperCase()}
                    </Text>
                    <WardrobeRow label={t("wardrobe_essentials")} swatches={sd.wardrobe.essentials} colors={colors} />
                    <WardrobeRow label={t("wardrobe_accents")} swatches={sd.wardrobe.accents} colors={colors} />
                    <WardrobeRow label={t("wardrobe_neutrals")} swatches={sd.wardrobe.neutrals} colors={colors} />
                    <WardrobeRow label={t("wardrobe_avoid")} swatches={sd.wardrobe.avoid} colors={colors} isAvoid />
                  </View>
                );
              })}
            </SubSection>
          </BlurredSection>

          {/* MAKEUP SECTION — blurred if no tier 3 */}
          <BlurredSection
            title={t("makeup_section")}
            subtitle={t("makeup_subtitle")}
            locked={!canMakeup}
            onUnlock={() => router.push("/subscribe")}
            unlockLabel={t("unlock_to_see")}
            colors={colors}
          >
            <MakeupRow label={t("makeup_foundation")} swatches={profile.makeup.foundation} colors={colors} />
            <MakeupRow label={t("makeup_corrector")} swatches={profile.makeup.corrector} colors={colors} />
            <MakeupRow label={t("makeup_concealer")} swatches={profile.makeup.concealer} colors={colors} />
            <MakeupRow label={t("makeup_blush")} swatches={profile.makeup.blush} colors={colors} />
            <MakeupRow label={t("makeup_bronzer")} swatches={profile.makeup.bronzer} colors={colors} />
            <MakeupRow label={t("makeup_highlighter")} swatches={profile.makeup.highlighter} colors={colors} />
            <MakeupRow label={t("makeup_eye_pencil")} swatches={profile.makeup.eyePencil} colors={colors} />
            <MakeupRow label={t("makeup_brow_pencil")} swatches={profile.makeup.browPencil} colors={colors} />
            <MakeupRow label={t("makeup_mascara")} swatches={profile.makeup.mascara} colors={colors} />
            <MakeupRow label={t("makeup_lip_liner")} swatches={profile.makeup.lipLiner} colors={colors} />
            <MakeupRow label={t("makeup_gloss")} swatches={profile.makeup.gloss} colors={colors} />
            <MakeupRow label={t("makeup_lipstick")} swatches={profile.makeup.lipstick} colors={colors} isLast />
          </BlurredSection>

          {/* SHOP THE MAKEUP */}
          <Pressable
            onPress={() => Linking.openURL(SHOP_URL)}
            style={({ pressed }) => [
              styles.shopBtn,
              { borderColor: colors.foreground, opacity: pressed ? 0.7 : 1 },
            ]}
          >
            <Text style={[styles.shopBtnText, { color: colors.foreground }]}>
              {t("shop_makeup")} ↗
            </Text>
          </Pressable>

          {/* RESTART */}
          <Pressable
            onPress={() => { resetQuiz(); router.replace("/"); }}
            style={({ pressed }) => [styles.restartBtn, { borderColor: colors.border, opacity: pressed ? 0.7 : 1 }]}
          >
            <Text style={[styles.restartText, { color: colors.mutedForeground }]}>
              {t("restart_quiz")}
            </Text>
          </Pressable>

        </Animated.View>
      </ScrollView>
    </View>
  );
}

// ---- Sub-components ----

function Section({ title, subtitle, children, colors }: {
  title: string; subtitle: string; children: React.ReactNode;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{title}</Text>
      {subtitle ? <Text style={[styles.sectionSub, { color: colors.mutedForeground }]}>{subtitle}</Text> : null}
      {children}
    </View>
  );
}

function SubSection({ title, subtitle, children, colors }: {
  title: string; subtitle: string; children: React.ReactNode;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={styles.subSection}>
      <Text style={[styles.subSectionTitle, { color: colors.foreground }]}>{title}</Text>
      {subtitle ? <Text style={[styles.subSectionSub, { color: colors.mutedForeground }]}>{subtitle}</Text> : null}
      {children}
    </View>
  );
}

function BlurredSection({ title, subtitle, locked, onUnlock, unlockLabel, children, colors }: {
  title: string; subtitle: string; locked: boolean;
  onUnlock: () => void; unlockLabel: string;
  children: React.ReactNode; colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{title}</Text>
      {subtitle ? <Text style={[styles.sectionSub, { color: colors.mutedForeground }]}>{subtitle}</Text> : null}

      {locked ? (
        <View style={styles.blurWrap}>
          <View style={styles.blurInner} pointerEvents="none">
            {children}
          </View>
          {Platform.OS !== "web" ? (
            <BlurView intensity={90} tint="light" style={StyleSheet.absoluteFill} />
          ) : (
            <View style={[StyleSheet.absoluteFill, styles.webBlur]} />
          )}
          <Pressable
            onPress={onUnlock}
            style={({ pressed }) => [styles.unlockBtn, { backgroundColor: colors.foreground, opacity: pressed ? 0.85 : 1 }]}
          >
            <Text style={[styles.unlockBtnText, { color: colors.primaryForeground }]}>
              🔒 {unlockLabel}
            </Text>
          </Pressable>
        </View>
      ) : (
        children
      )}
    </View>
  );
}

function WardrobeRow({ label, swatches, colors, isAvoid }: {
  label: string; swatches: { hex: string }[];
  colors: ReturnType<typeof useColors>; isAvoid?: boolean;
}) {
  return (
    <View style={styles.wardrobeRow}>
      <Text style={[styles.wardrobeLabel, { color: isAvoid ? "#B8463B" : colors.accent }]}>
        {label.toUpperCase()}
      </Text>
      <View style={styles.swatchRow}>
        {swatches.map((s, i) => (
          <View key={i} style={[styles.wardrobeSwatch, { backgroundColor: s.hex }]} />
        ))}
      </View>
    </View>
  );
}

function MakeupRow({ label, swatches, colors, isLast }: {
  label: string; swatches: { hex: string }[];
  colors: ReturnType<typeof useColors>; isLast?: boolean;
}) {
  return (
    <View style={[styles.makeupRow, !isLast && { borderBottomWidth: 1, borderBottomColor: colors.border }]}>
      <Text style={[styles.makeupLabel, { color: colors.softInk as string }]}>{label}</Text>
      <View style={styles.swatchRow}>
        {swatches.map((s, i) => (
          <View key={i} style={[styles.makeupSwatch, { backgroundColor: s.hex }]} />
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { justifyContent: "center", alignItems: "center" },
  errText: { fontSize: 15, fontFamily: "Inter_400Regular" },
  errBtn: { padding: 16 },
  errBtnText: { fontSize: 15, fontFamily: "Inter_500Medium" },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 24,
    paddingBottom: 12,
  },
  backArrow: { fontSize: 22 },
  topTitle: { fontSize: 12, fontFamily: "Inter_400Regular", letterSpacing: 1.5 },
  scroll: { flex: 1 },
  scrollContent: { paddingHorizontal: 18, paddingTop: 4, gap: 14 },
  hero: { alignItems: "center", paddingVertical: 24, gap: 12 },
  badge: {
    paddingHorizontal: 18,
    paddingVertical: 7,
    borderRadius: 100,
  },
  badgeText: { fontSize: 10, fontFamily: "Inter_600SemiBold", letterSpacing: 2.5 },
  heroTitle: { fontSize: 26, fontFamily: "Inter_400Regular", textAlign: "center" },
  heroSeason: { fontStyle: "italic", fontFamily: "Inter_400Regular" },
  heroDesc: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    lineHeight: 22,
    textAlign: "center",
    maxWidth: 320,
  },
  section: {
    borderRadius: 18,
    borderWidth: 1,
    padding: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 1,
  },
  sectionTitle: { fontSize: 15, fontFamily: "Inter_600SemiBold", marginBottom: 4 },
  sectionSub: { fontSize: 12, fontFamily: "Inter_400Regular", fontStyle: "italic", marginBottom: 16 },
  subSection: { marginBottom: 16 },
  subSectionTitle: { fontSize: 13, fontFamily: "Inter_600SemiBold", marginBottom: 3 },
  subSectionSub: { fontSize: 11, fontFamily: "Inter_400Regular", fontStyle: "italic", marginBottom: 10 },
  swatchGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  paletteSwatch: {
    width: 40,
    height: 40,
    borderRadius: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 1,
  },
  swatchRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
    marginTop: 4,
  },
  avoidChip: { alignItems: "center", position: "relative" },
  avoidSwatch: {
    width: 40,
    height: 40,
    borderRadius: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 1,
  },
  avoidX: {
    position: "absolute",
    top: 0,
    right: -2,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: "#B8463B",
    alignItems: "center",
    justifyContent: "center",
  },
  avoidXText: { color: "#FFF", fontSize: 8, fontFamily: "Inter_700Bold" },
  labeledSwatch: { alignItems: "center", width: 52 },
  hairSwatch: {
    width: 48,
    height: 48,
    borderRadius: 24,
    marginBottom: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.12,
    shadowRadius: 3,
    elevation: 1,
  },
  jewelrySwatch: {
    width: 48,
    height: 48,
    borderRadius: 8,
    marginBottom: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.12,
    shadowRadius: 3,
    elevation: 1,
  },
  swatchLabel: {
    fontSize: 9,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
    lineHeight: 13,
  },
  wardrobeSeasonBlock: {
    borderTopWidth: 1,
    paddingTop: 14,
    marginBottom: 8,
  },
  wardrobeSeasonTitle: {
    fontSize: 11,
    fontFamily: "Inter_700Bold",
    letterSpacing: 2,
    marginBottom: 10,
  },
  wardrobeRow: { marginBottom: 12 },
  wardrobeLabel: {
    fontSize: 9,
    fontFamily: "Inter_600SemiBold",
    letterSpacing: 1.5,
    marginBottom: 6,
  },
  wardrobeSwatch: {
    width: 36,
    height: 36,
    borderRadius: 8,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.08,
    shadowRadius: 2,
    elevation: 1,
  },
  makeupRow: {
    paddingVertical: 12,
    gap: 8,
  },
  makeupLabel: {
    fontSize: 12,
    fontFamily: "Inter_600SemiBold",
    marginBottom: 4,
  },
  makeupSwatch: {
    width: 32,
    height: 32,
    borderRadius: 8,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  blurWrap: {
    borderRadius: 12,
    overflow: "hidden",
    minHeight: 120,
  },
  blurInner: {
    padding: 4,
    opacity: 0.08,
  },
  webBlur: {
    backgroundColor: "rgba(245,240,235,0.97)",
    backdropFilter: "blur(18px)",
  },
  unlockBtn: {
    position: "absolute",
    bottom: 16,
    left: "50%",
    transform: [{ translateX: -80 }],
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 100,
    width: 160,
    alignItems: "center",
  },
  unlockBtnText: {
    fontSize: 12,
    fontFamily: "Inter_600SemiBold",
    letterSpacing: 0.3,
  },
  premiumBanner: {
    borderRadius: 18,
    padding: 24,
    alignItems: "center",
    gap: 8,
  },
  premiumBannerTitle: {
    color: "#FFFFFF",
    fontSize: 17,
    fontFamily: "Inter_600SemiBold",
    textAlign: "center",
  },
  premiumBannerSub: {
    color: "rgba(255,255,255,0.6)",
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
  },
  premiumBannerBtn: {
    marginTop: 8,
    backgroundColor: "rgba(255,255,255,0.12)",
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 100,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.2)",
  },
  premiumBannerBtnText: {
    color: "#FFFFFF",
    fontSize: 13,
    fontFamily: "Inter_500Medium",
  },
  shopBtn: {
    borderWidth: 1.5,
    borderRadius: 12,
    paddingVertical: 18,
    alignItems: "center",
    marginTop: 4,
  },
  shopBtnText: { fontSize: 15, fontFamily: "Inter_500Medium", letterSpacing: 0.3 },
  restartBtn: {
    borderWidth: 1,
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: "center",
  },
  restartText: { fontSize: 14, fontFamily: "Inter_400Regular", fontStyle: "italic" },
});

import * as Haptics from "expo-haptics";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAuth } from "@/context/AuthContext";
import { useLanguage } from "@/context/LanguageContext";
import { useColors } from "@/hooks/useColors";

export default function AuthScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { t } = useLanguage();
  const { register, login, continueAsGuest } = useAuth();
  const params = useLocalSearchParams<{ returnTo?: string }>();

  const [isLogin, setIsLogin] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const topInset = Platform.OS === "web" ? 67 : insets.top;
  const bottomInset = Platform.OS === "web" ? 34 : insets.bottom;

  const handleSubmit = async () => {
    if (!email.trim() || !password.trim()) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setError("");
    setLoading(true);
    try {
      if (isLogin) {
        await login(email.trim(), password);
      } else {
        await register(email.trim(), password);
      }
      if (params.returnTo === "subscribe") {
        router.replace("/subscribe");
      } else {
        router.back();
      }
    } catch (e: any) {
      if (e?.message === "email_taken") setError(t("auth_email_taken"));
      else setError(t("auth_invalid"));
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setLoading(false);
    }
  };

  const handleGuest = () => {
    continueAsGuest();
    if (params.returnTo === "subscribe") {
      router.replace("/subscribe");
    } else {
      router.back();
    }
  };

  return (
    <KeyboardAvoidingView
      style={[styles.container, { backgroundColor: colors.background }]}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <View style={[styles.topBar, { paddingTop: topInset + 12 }]}>
        <TouchableOpacity onPress={() => router.back()} hitSlop={12}>
          <Text style={[styles.backArrow, { color: colors.mutedForeground }]}>←</Text>
        </TouchableOpacity>
        <View style={{ width: 28 }} />
      </View>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={{ paddingHorizontal: 28, paddingBottom: bottomInset + 32 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={[styles.title, { color: colors.foreground }]}>
            {isLogin ? t("auth_title_login") : t("auth_title_register")}
          </Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            {isLogin
              ? "Sign in to access your analysis"
              : "Create an account to save your results"}
          </Text>
        </View>

        <View style={styles.form}>
          <View style={styles.fieldWrap}>
            <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>
              {t("auth_email")}
            </Text>
            <TextInput
              value={email}
              onChangeText={setEmail}
              style={[
                styles.input,
                {
                  backgroundColor: colors.card,
                  borderColor: colors.border,
                  color: colors.foreground,
                },
              ]}
              placeholder="hello@example.com"
              placeholderTextColor={colors.mutedForeground}
              keyboardType="email-address"
              autoCapitalize="none"
              autoCorrect={false}
            />
          </View>

          <View style={styles.fieldWrap}>
            <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>
              {t("auth_password")}
            </Text>
            <TextInput
              value={password}
              onChangeText={setPassword}
              style={[
                styles.input,
                {
                  backgroundColor: colors.card,
                  borderColor: colors.border,
                  color: colors.foreground,
                },
              ]}
              placeholder="••••••••"
              placeholderTextColor={colors.mutedForeground}
              secureTextEntry
              autoCapitalize="none"
            />
          </View>

          {error ? (
            <Text style={styles.errorText}>{error}</Text>
          ) : null}

          <Pressable
            onPress={handleSubmit}
            disabled={loading || !email.trim() || !password.trim()}
            style={({ pressed }) => [
              styles.submitBtn,
              {
                backgroundColor: email.trim() && password.trim() ? colors.foreground : colors.border,
                opacity: pressed ? 0.85 : 1,
              },
            ]}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={[styles.submitBtnText, { color: colors.primaryForeground }]}>
                {isLogin ? t("auth_signin") : t("auth_register")}
              </Text>
            )}
          </Pressable>

          <Pressable
            onPress={() => { setIsLogin(!isLogin); setError(""); }}
            style={styles.switchBtn}
          >
            <Text style={[styles.switchBtnText, { color: colors.accent }]}>
              {isLogin ? t("auth_switch_to_register") : t("auth_switch_to_login")}
            </Text>
          </Pressable>

          <View style={[styles.dividerRow]}>
            <View style={[styles.dividerLine, { backgroundColor: colors.border }]} />
            <Text style={[styles.dividerText, { color: colors.mutedForeground }]}>or</Text>
            <View style={[styles.dividerLine, { backgroundColor: colors.border }]} />
          </View>

          <Pressable
            onPress={handleGuest}
            style={({ pressed }) => [
              styles.guestBtn,
              { borderColor: colors.border, opacity: pressed ? 0.7 : 1 },
            ]}
          >
            <Text style={[styles.guestBtnText, { color: colors.mutedForeground }]}>
              {t("auth_guest")}
            </Text>
          </Pressable>
        </View>

        <Text style={[styles.securityNote, { color: colors.mutedForeground }]}>
          🔒 Your data is stored securely on this device.
        </Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 24,
    paddingBottom: 12,
  },
  backArrow: { fontSize: 22 },
  scroll: { flex: 1 },
  header: { paddingTop: 20, paddingBottom: 36, gap: 10 },
  title: { fontSize: 26, fontFamily: "Inter_600SemiBold" },
  subtitle: { fontSize: 14, fontFamily: "Inter_400Regular", lineHeight: 22 },
  form: { gap: 16 },
  fieldWrap: { gap: 6 },
  fieldLabel: { fontSize: 12, fontFamily: "Inter_500Medium", letterSpacing: 0.5 },
  input: {
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
  },
  errorText: {
    color: "#B8463B",
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
  },
  submitBtn: {
    borderRadius: 12,
    paddingVertical: 18,
    alignItems: "center",
    marginTop: 4,
  },
  submitBtnText: { fontSize: 15, fontFamily: "Inter_500Medium" },
  switchBtn: { alignItems: "center", paddingVertical: 8 },
  switchBtnText: { fontSize: 13, fontFamily: "Inter_400Regular" },
  dividerRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginVertical: 4,
  },
  dividerLine: { flex: 1, height: 1 },
  dividerText: { fontSize: 12, fontFamily: "Inter_400Regular" },
  guestBtn: {
    borderWidth: 1,
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: "center",
  },
  guestBtnText: { fontSize: 14, fontFamily: "Inter_400Regular" },
  securityNote: {
    fontSize: 11,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
    marginTop: 32,
  },
});
